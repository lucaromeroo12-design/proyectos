import { Request, Response, NextFunction } from 'express';
import { Prisma } from '@prisma/client';
import { logAuditEvent, AUDIT_EVENTS } from '../services/auditService';

export interface AppError extends Error {
  statusCode?: number;
  isOperational?: boolean;
}

/**
 * Create a custom error
 */
export function createError(message: string, statusCode: number = 500): AppError {
  const error: AppError = new Error(message);
  error.statusCode = statusCode;
  error.isOperational = true;
  return error;
}

/**
 * Handle Prisma errors
 */
function handlePrismaError(error: Prisma.PrismaClientKnownRequestError): AppError {
  let message = 'Database error';
  let statusCode = 500;

  switch (error.code) {
    case 'P2002':
      message = 'A record with this information already exists';
      statusCode = 409;
      break;
    case 'P2025':
      message = 'Record not found';
      statusCode = 404;
      break;
    case 'P2003':
      message = 'Invalid reference to related record';
      statusCode = 400;
      break;
    case 'P2014':
      message = 'Invalid data provided';
      statusCode = 400;
      break;
    default:
      message = `Database error: ${error.message}`;
  }

  const appError: AppError = new Error(message);
  appError.statusCode = statusCode;
  appError.isOperational = true;
  return appError;
}

/**
 * Handle JWT errors
 */
function handleJWTError(error: Error): AppError {
  let message = 'Authentication failed';
  
  if (error.message.includes('jwt expired')) {
    message = 'Token expired. Please login again.';
  } else if (error.message.includes('jwt malformed')) {
    message = 'Invalid token format.';
  } else if (error.message.includes('invalid signature')) {
    message = 'Invalid token signature.';
  }

  const appError: AppError = new Error(message);
  appError.statusCode = 401;
  appError.isOperational = true;
  return appError;
}

/**
 * Send error response in development
 */
function sendErrorDev(err: AppError, res: Response) {
  res.status(err.statusCode || 500).json({
    success: false,
    error: {
      message: err.message,
      stack: err.stack,
      statusCode: err.statusCode,
    },
  });
}

/**
 * Send error response in production
 */
function sendErrorProd(err: AppError, res: Response) {
  // Only send operational errors to client
  if (err.isOperational) {
    res.status(err.statusCode || 500).json({
      success: false,
      message: err.message,
    });
  } else {
    // Don't leak error details in production
    console.error('ERROR:', err);
    res.status(500).json({
      success: false,
      message: 'Something went wrong!',
    });
  }
}

/**
 * Global error handling middleware
 */
export function globalErrorHandler(
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) {
  let error: AppError = { ...err } as AppError;
  error.message = err.message;

  // Log error for audit purposes
  const logError = async () => {
    try {
      await logAuditEvent({
        userId: req.user?.userId,
        event: AUDIT_EVENTS.ADMIN_ACTION,
        details: JSON.stringify({
          error: error.message,
          statusCode: error.statusCode,
          url: req.url,
          method: req.method,
        }),
        ipAddress: req.ip,
        userAgent: req.get('User-Agent'),
      });
    } catch (logErr) {
      console.error('Failed to log error:', logErr);
    }
  };

  // Handle specific error types
  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    error = handlePrismaError(err);
  } else if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    error = handleJWTError(err);
  } else if (err.name === 'ValidationError') {
    error.statusCode = 400;
    error.isOperational = true;
  } else if (err.name === 'CastError') {
    error.statusCode = 400;
    error.isOperational = true;
    error.message = 'Invalid data format';
  }

  // Set default status code if not set
  if (!error.statusCode) {
    error.statusCode = 500;
  }

  // Log error asynchronously
  logError();

  // Send appropriate error response
  if (process.env.NODE_ENV === 'development') {
    sendErrorDev(error, res);
  } else {
    sendErrorProd(error, res);
  }
}

/**
 * Handle unhandled promise rejections
 */
export function handleUnhandledRejection() {
  process.on('unhandledRejection', (reason: any, promise: Promise<any>) => {
    console.log('Unhandled Rejection at:', promise, 'reason:', reason);
    // Close server gracefully and exit
    process.exit(1);
  });
}

/**
 * Handle uncaught exceptions
 */
export function handleUncaughtException() {
  process.on('uncaughtException', (err: Error) => {
    console.log('Uncaught Exception:', err.name, err.message);
    console.log('Shutting down...');
    process.exit(1);
  });
}

/**
 * Async wrapper to catch errors in async route handlers
 */
export function catchAsync(fn: Function) {
  return (req: Request, res: Response, next: NextFunction) => {
    fn(req, res, next).catch(next);
  };
}
