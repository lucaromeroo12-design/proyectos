import { Request, Response, NextFunction } from 'express';
import { UserRole } from '@prisma/client';
import { verifyToken, extractTokenFromHeader, hasRole, JWTPayload } from '../utils/auth';
import prisma from '../services/database';

// Extend Express Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: JWTPayload & {
        id: string;
        customer?: any;
        branch?: any;
      };
    }
  }
}

/**
 * Middleware to authenticate JWT token
 */
export async function authenticateToken(req: Request, res: Response, next: NextFunction) {
  try {
    const token = extractTokenFromHeader(req.headers.authorization);

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access token is required',
      });
    }

    const payload = verifyToken(token);

    // Fetch full user data from database
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      include: {
        customer: true,
        branch: true,
      },
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User not found',
      });
    }

    // Attach user to request
    req.user = {
      ...payload,
      id: user.id,
      customer: user.customer,
      branch: user.branch,
    };

    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: error instanceof Error ? error.message : 'Invalid token',
    });
  }
}

/**
 * Middleware to authorize specific roles
 */
export function authorizeRoles(...roles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }

    if (!hasRole(req.user.role, roles)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions',
      });
    }

    next();
  };
}

/**
 * Middleware for admin-only routes
 */
export const requireAdmin = authorizeRoles(UserRole.ADMIN);

/**
 * Middleware for branch manager routes
 */
export const requireBranchManager = authorizeRoles(UserRole.BRANCH, UserRole.ADMIN);

/**
 * Middleware for customer routes
 */
export const requireCustomer = authorizeRoles(UserRole.CUSTOMER, UserRole.ADMIN);

/**
 * Middleware for authenticated routes (any role)
 */
export const requireAuth = authenticateToken;
