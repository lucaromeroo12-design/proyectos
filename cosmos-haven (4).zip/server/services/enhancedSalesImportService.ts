import * as XLSX from 'xlsx';
import csv from 'csv-parser';
import { Readable } from 'stream';
import { UserRole } from '@prisma/client';
import prisma from './database';
import { calculatePoints, determineLoyaltyLevel } from '../utils/loyaltyLevels';
import { logAuditEvent, AUDIT_EVENTS } from './auditService';

export interface ImportedSaleRow {
  nombre_cliente: string;
  dni_cliente: string;
  sucursal: string;
  fecha: string;
  monto: number;
  nro_factura: string;
}

export interface ValidationError {
  row: number;
  field: string;
  message: string;
  suggestion?: string;
}

export interface ProcessedSale extends ImportedSaleRow {
  row: number;
  pointsToEarn: number;
  isValid: boolean;
  errors: ValidationError[];
  customerId?: string;
  branchId?: string;
}

export interface SalesImportResult {
  success: boolean;
  processedCount: number;
  ignoredCount: number;
  newCustomersCreated: number;
  totalPointsAdded: number;
  errors: ValidationError[];
  summary: string;
}

export interface SalesPreviewResponse {
  success: boolean;
  preview: ProcessedSale[];
  totalRows: number;
  validRows: number;
  invalidRows: number;
  duplicateInvoices: string[];
}

export class EnhancedSalesImportService {
  /**
   * Parse Excel or CSV file
   */
  static async parseFile(buffer: Buffer, fileName: string): Promise<any[]> {
    const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls');
    
    if (isExcel) {
      return this.parseExcelFile(buffer);
    } else {
      return this.parseCSVFile(buffer);
    }
  }

  private static parseExcelFile(buffer: Buffer): any[] {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    
    return XLSX.utils.sheet_to_json(worksheet, { 
      defval: '',
      blankrows: false 
    });
  }

  private static async parseCSVFile(buffer: Buffer): Promise<any[]> {
    return new Promise((resolve, reject) => {
      const results: any[] = [];
      const stream = Readable.from(buffer.toString());
      
      stream
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', () => resolve(results))
        .on('error', reject);
    });
  }

  /**
   * Validate a single sale row with database checks
   */
  static async validateSaleRow(row: any, rowIndex: number): Promise<{
    isValid: boolean;
    errors: ValidationError[];
    suggestions: string[];
  }> {
    const errors: ValidationError[] = [];
    const suggestions: string[] = [];

    // Required fields validation
    const requiredFields = ['nombre_cliente', 'dni_cliente', 'sucursal', 'fecha', 'monto', 'nro_factura'];
    for (const field of requiredFields) {
      if (!row[field] || row[field].toString().trim() === '') {
        errors.push({
          row: rowIndex,
          field,
          message: `Campo requerido: ${field}`,
        });
      }
    }

    // DNI validation
    if (row.dni_cliente) {
      const dni = row.dni_cliente.toString().trim();
      if (!/^\d{7,8}$/.test(dni)) {
        errors.push({
          row: rowIndex,
          field: 'dni_cliente',
          message: 'DNI debe contener 7 u 8 dígitos',
          suggestion: 'Ejemplo: 12345678',
        });
      }
    }

    // Amount validation
    if (row.monto) {
      const amount = Number(row.monto);
      if (isNaN(amount) || amount <= 0) {
        errors.push({
          row: rowIndex,
          field: 'monto',
          message: 'Monto debe ser un número positivo',
          suggestion: 'Ejemplo: 2500.50',
        });
      } else if (amount > 1000000) {
        errors.push({
          row: rowIndex,
          field: 'monto',
          message: 'Monto parece demasiado alto',
          suggestion: 'Verifique que el monto sea correcto',
        });
      }
    }

    // Date validation
    if (row.fecha) {
      const dateStr = row.fecha.toString().trim();
      
      // Try multiple date formats
      let isValidDate = false;
      let parsedDate: Date | null = null;

      // Format: YYYY-MM-DD
      if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        parsedDate = new Date(dateStr);
        isValidDate = !isNaN(parsedDate.getTime());
      }
      // Format: DD/MM/YYYY
      else if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateStr)) {
        const [day, month, year] = dateStr.split('/');
        parsedDate = new Date(`${year}-${month}-${day}`);
        isValidDate = !isNaN(parsedDate.getTime());
        suggestions.push(`Fecha convertida de ${dateStr} a formato YYYY-MM-DD`);
      }
      // Format: DD-MM-YYYY
      else if (/^\d{2}-\d{2}-\d{4}$/.test(dateStr)) {
        const [day, month, year] = dateStr.split('-');
        parsedDate = new Date(`${year}-${month}-${day}`);
        isValidDate = !isNaN(parsedDate.getTime());
        suggestions.push(`Fecha convertida de ${dateStr} a formato YYYY-MM-DD`);
      }

      if (!isValidDate) {
        errors.push({
          row: rowIndex,
          field: 'fecha',
          message: 'Fecha inválida',
          suggestion: 'Use formato YYYY-MM-DD, DD/MM/YYYY o DD-MM-YYYY',
        });
      } else if (parsedDate) {
        const now = new Date();
        const oneYearAgo = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
        
        if (parsedDate > now) {
          errors.push({
            row: rowIndex,
            field: 'fecha',
            message: 'La fecha no puede ser futura',
          });
        } else if (parsedDate < oneYearAgo) {
          suggestions.push('Fecha es anterior a un año - verifique que sea correcta');
        }
      }
    }

    // Invoice number validation
    if (row.nro_factura) {
      const invoice = row.nro_factura.toString().trim();
      if (invoice.length < 3) {
        errors.push({
          row: rowIndex,
          field: 'nro_factura',
          message: 'Número de factura demasiado corto',
          suggestion: 'Debe tener al menos 3 caracteres',
        });
      }

      // Check for duplicate in database
      const existingPurchase = await prisma.purchase.findUnique({
        where: { invoiceNumber: invoice },
      });

      if (existingPurchase) {
        errors.push({
          row: rowIndex,
          field: 'nro_factura',
          message: 'Número de factura ya existe en la base de datos',
        });
      }
    }

    // Branch validation - suggest similar names
    if (row.sucursal) {
      const branchName = row.sucursal.toString().trim();
      const existingBranch = await prisma.branch.findFirst({
        where: {
          name: {
            equals: branchName,
            mode: 'insensitive',
          },
        },
      });

      if (!existingBranch) {
        // Look for similar branch names
        const allBranches = await prisma.branch.findMany({
          where: { isActive: true },
          select: { name: true },
        });

        const similarBranches = allBranches.filter(b => 
          b.name.toLowerCase().includes(branchName.toLowerCase()) ||
          branchName.toLowerCase().includes(b.name.toLowerCase())
        );

        if (similarBranches.length > 0) {
          suggestions.push(`Sucursal no encontrada. ¿Quiso decir: ${similarBranches.map(b => b.name).join(', ')}?`);
        } else {
          suggestions.push(`Sucursal "${branchName}" será creada automáticamente`);
        }
      }
    }

    // Customer name suggestions
    if (row.nombre_cliente) {
      const name = row.nombre_cliente.toString().trim();
      if (name.length < 3) {
        errors.push({
          row: rowIndex,
          field: 'nombre_cliente',
          message: 'Nombre demasiado corto',
          suggestion: 'Debe tener al menos 3 caracteres',
        });
      }

      // Check for common issues
      if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(name)) {
        suggestions.push('Nombre contiene caracteres especiales - verifique que sea correcto');
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      suggestions,
    };
  }

  /**
   * Preview sales data with enhanced validation
   */
  static async previewSales(buffer: Buffer, fileName: string): Promise<SalesPreviewResponse> {
    try {
      const rawData = await this.parseFile(buffer, fileName);
      const preview: ProcessedSale[] = [];
      let validRows = 0;
      let invalidRows = 0;
      const duplicateInvoices: string[] = [];

      // Check for duplicate invoices within the file
      const invoiceNumbers = new Set<string>();
      const fileDuplicates = new Set<string>();

      rawData.forEach(row => {
        if (row.nro_factura) {
          const invoice = row.nro_factura.toString().trim();
          if (invoiceNumbers.has(invoice)) {
            fileDuplicates.add(invoice);
          }
          invoiceNumbers.add(invoice);
        }
      });

      for (let i = 0; i < Math.min(rawData.length, 50); i++) {
        const row = rawData[i];
        const validation = await this.validateSaleRow(row, i + 1);
        
        // Check for file duplicates
        if (row.nro_factura && fileDuplicates.has(row.nro_factura.toString().trim())) {
          validation.errors.push({
            row: i + 1,
            field: 'nro_factura',
            message: 'Número de factura duplicado en el archivo',
          });
        }

        const pointsToEarn = row.monto ? calculatePoints(Number(row.monto)) : 0;

        const processedSale: ProcessedSale = {
          row: i + 1,
          nombre_cliente: row.nombre_cliente || '',
          dni_cliente: row.dni_cliente?.toString() || '',
          sucursal: row.sucursal || '',
          fecha: row.fecha || '',
          monto: Number(row.monto) || 0,
          nro_factura: row.nro_factura?.toString() || '',
          pointsToEarn,
          isValid: validation.isValid,
          errors: validation.errors,
        };

        preview.push(processedSale);

        if (validation.isValid) {
          validRows++;
        } else {
          invalidRows++;
        }
      }

      return {
        success: true,
        preview,
        totalRows: rawData.length,
        validRows,
        invalidRows,
        duplicateInvoices: Array.from(fileDuplicates),
      };
    } catch (error) {
      console.error('Preview error:', error);
      return {
        success: false,
        preview: [],
        totalRows: 0,
        validRows: 0,
        invalidRows: 0,
        duplicateInvoices: [],
      };
    }
  }

  /**
   * Process and import sales data into database
   */
  static async processSales(
    buffer: Buffer, 
    fileName: string, 
    userId: string
  ): Promise<SalesImportResult> {
    try {
      const rawData = await this.parseFile(buffer, fileName);
      let processedCount = 0;
      let ignoredCount = 0;
      let newCustomersCreated = 0;
      let totalPointsAdded = 0;
      const errors: ValidationError[] = [];

      // Process in transaction for data integrity
      const result = await prisma.$transaction(async (tx) => {
        for (let i = 0; i < rawData.length; i++) {
          const row = rawData[i];
          const validation = await this.validateSaleRow(row, i + 1);

          if (!validation.isValid) {
            errors.push(...validation.errors);
            ignoredCount++;
            continue;
          }

          try {
            // Normalize data
            const normalizedDni = row.dni_cliente.toString().trim();
            const normalizedBranchName = row.sucursal.toString().trim();
            const amount = Number(row.monto);
            const pointsEarned = calculatePoints(amount);

            // Find or create customer
            let customer = await tx.customer.findUnique({
              where: { dni: normalizedDni },
              include: { user: true },
            });

            if (!customer) {
              // Create new user and customer
              const user = await tx.user.create({
                data: {
                  email: `${normalizedDni}@imported.com`,
                  password: 'imported', // Will need to be changed on first login
                  name: row.nombre_cliente.toString().trim(),
                  role: UserRole.CUSTOMER,
                },
              });

              customer = await tx.customer.create({
                data: {
                  userId: user.id,
                  dni: normalizedDni,
                  points: 0,
                  loyaltyLevel: determineLoyaltyLevel(0),
                  totalSpent: 0,
                },
                include: { user: true },
              });

              newCustomersCreated++;
            }

            // Find or create branch
            let branch = await tx.branch.findFirst({
              where: {
                name: {
                  equals: normalizedBranchName,
                  mode: 'insensitive',
                },
              },
            });

            if (!branch) {
              branch = await tx.branch.create({
                data: {
                  name: normalizedBranchName,
                  address: 'Dirección a definir',
                  isActive: true,
                },
              });
            }

            // Parse date
            let purchaseDate: Date;
            if (/^\d{4}-\d{2}-\d{2}$/.test(row.fecha)) {
              purchaseDate = new Date(row.fecha);
            } else if (/^\d{2}\/\d{2}\/\d{4}$/.test(row.fecha)) {
              const [day, month, year] = row.fecha.split('/');
              purchaseDate = new Date(`${year}-${month}-${day}`);
            } else if (/^\d{2}-\d{2}-\d{4}$/.test(row.fecha)) {
              const [day, month, year] = row.fecha.split('-');
              purchaseDate = new Date(`${year}-${month}-${day}`);
            } else {
              purchaseDate = new Date(row.fecha);
            }

            // Create purchase
            await tx.purchase.create({
              data: {
                customerId: customer.id,
                branchId: branch.id,
                amount,
                pointsEarned,
                products: JSON.stringify(['Venta importada']),
                invoiceNumber: row.nro_factura.toString().trim(),
                purchaseDate,
              },
            });

            // Update customer points and total spent
            const newTotalSpent = customer.totalSpent + amount;
            const newLoyaltyLevel = determineLoyaltyLevel(newTotalSpent);
            
            await tx.customer.update({
              where: { id: customer.id },
              data: {
                points: customer.points + pointsEarned,
                totalSpent: newTotalSpent,
                loyaltyLevel: newLoyaltyLevel,
              },
            });

            totalPointsAdded += pointsEarned;
            processedCount++;

          } catch (error) {
            console.error(`Error processing row ${i + 1}:`, error);
            errors.push({
              row: i + 1,
              field: 'general',
              message: `Error al procesar: ${error}`,
            });
            ignoredCount++;
          }
        }

        return { processedCount, ignoredCount, newCustomersCreated, totalPointsAdded };
      });

      // Log the import event
      await logAuditEvent({
        userId,
        event: AUDIT_EVENTS.SALES_IMPORT,
        details: JSON.stringify({
          fileName,
          totalRows: rawData.length,
          processedCount: result.processedCount,
          ignoredCount: result.ignoredCount,
          newCustomersCreated: result.newCustomersCreated,
          totalPointsAdded: result.totalPointsAdded,
        }),
      });

      const summary = `Se cargaron correctamente ${result.processedCount} ventas. Se ignoraron ${result.ignoredCount} registros.${
        result.newCustomersCreated > 0 ? ` Se crearon ${result.newCustomersCreated} nuevos clientes.` : ''
      }`;

      return {
        success: true,
        processedCount: result.processedCount,
        ignoredCount: result.ignoredCount,
        newCustomersCreated: result.newCustomersCreated,
        totalPointsAdded: result.totalPointsAdded,
        errors,
        summary,
      };

    } catch (error) {
      console.error('Process sales error:', error);
      return {
        success: false,
        processedCount: 0,
        ignoredCount: 0,
        newCustomersCreated: 0,
        totalPointsAdded: 0,
        errors: [
          {
            row: 0,
            field: 'general',
            message: `Error al procesar archivo: ${error}`,
          },
        ],
        summary: 'Error al procesar el archivo',
      };
    }
  }
}
