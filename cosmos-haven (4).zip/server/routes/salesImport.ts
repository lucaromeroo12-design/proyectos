import { RequestHandler } from "express";
import multer from "multer";
import { EnhancedSalesImportService } from "../services/enhancedSalesImportService";
import { SalesImportResponse, SalesPreviewResponse } from "../../shared/salesImport";

// Configure multer for file upload
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
      'application/vnd.ms-excel', // .xls
      'text/csv', // .csv
      'application/csv'
    ];
    
    const allowedExtensions = ['.xlsx', '.xls', '.csv'];
    const hasValidExtension = allowedExtensions.some(ext => 
      file.originalname.toLowerCase().endsWith(ext)
    );
    
    if (allowedTypes.includes(file.mimetype) || hasValidExtension) {
      cb(null, true);
    } else {
      cb(new Error('Solo se permiten archivos .xlsx, .xls o .csv'));
    }
  }
});

export const uploadMiddleware = upload.single('file');

export const previewSalesImport: RequestHandler = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No se ha subido ningún archivo'
      });
    }

    const result: SalesPreviewResponse = await EnhancedSalesImportService.previewSales(
      req.file.buffer,
      req.file.originalname
    );

    res.json(result);
  } catch (error) {
    console.error('Error in preview sales import:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

export const processSalesImport: RequestHandler = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No se ha subido ningún archivo'
      });
    }

    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Usuario no autenticado'
      });
    }

    const result = await EnhancedSalesImportService.processSales(
      req.file.buffer,
      req.file.originalname,
      req.user.userId
    );

    const response: SalesImportResponse = {
      success: result.success,
      processedCount: result.processedCount,
      ignoredCount: result.ignoredCount,
      errors: result.errors,
      summary: result.summary,
      newCustomersCreated: 0, // Will be enhanced later
      totalPointsAdded: 0 // Will be enhanced later
    };

    res.json(response);
  } catch (error) {
    console.error('Error in process sales import:', error);
    res.status(500).json({
      success: false,
      processedCount: 0,
      ignoredCount: 0,
      errors: ['Error interno del servidor'],
      summary: 'Error al procesar el archivo',
      newCustomersCreated: 0,
      totalPointsAdded: 0
    });
  }
};

// Note: Authentication middleware is now handled by the main auth system
