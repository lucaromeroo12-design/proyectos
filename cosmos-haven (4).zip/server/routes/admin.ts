import { RequestHandler } from 'express';
import prisma from '../services/database';

/**
 * Get admin dashboard metrics
 */
export const getAdminDashboard: RequestHandler = async (req, res) => {
  try {
    const [
      totalCustomers,
      totalBranches,
      totalSales,
      totalPointsRedeemed,
      recentPurchases,
      topCustomers,
      branchStats,
    ] = await Promise.all([
      // Total customers
      prisma.customer.count(),
      
      // Total active branches
      prisma.branch.count({ where: { isActive: true } }),
      
      // Total sales amount
      prisma.purchase.aggregate({
        _sum: { amount: true },
        _count: { id: true },
      }),
      
      // Total points redeemed
      prisma.redemption.aggregate({
        _sum: { pointsUsed: true },
      }),
      
      // Recent purchases
      prisma.purchase.findMany({
        take: 10,
        orderBy: { purchaseDate: 'desc' },
        include: {
          customer: {
            include: { user: true },
          },
          branch: true,
        },
      }),
      
      // Top customers by total spent
      prisma.customer.findMany({
        take: 10,
        orderBy: { totalSpent: 'desc' },
        include: {
          user: { select: { name: true, email: true } },
        },
      }),
      
      // Branch statistics
      prisma.branch.findMany({
        where: { isActive: true },
        include: {
          purchases: {
            select: {
              amount: true,
              customerId: true,
            },
          },
        },
      }),
    ]);

    // Calculate monthly sales for chart
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlySales = await prisma.purchase.groupBy({
      by: ['purchaseDate'],
      where: {
        purchaseDate: {
          gte: sixMonthsAgo,
        },
      },
      _sum: {
        amount: true,
      },
      _count: {
        id: true,
      },
    });

    // Group by month
    const monthlyData: { [key: string]: { sales: number; count: number } } = {};
    monthlySales.forEach(item => {
      const monthKey = item.purchaseDate.toISOString().slice(0, 7);
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = { sales: 0, count: 0 };
      }
      monthlyData[monthKey].sales += item._sum.amount || 0;
      monthlyData[monthKey].count += item._count.id;
    });

    const chartData = Object.entries(monthlyData)
      .map(([month, data]) => ({
        month,
        sales: data.sales,
        transactions: data.count,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));

    // Calculate branch performance
    const branchPerformance = branchStats.map(branch => {
      const totalSales = branch.purchases.reduce((sum, p) => sum + p.amount, 0);
      const uniqueCustomers = new Set(branch.purchases.map(p => p.customerId)).size;
      
      return {
        id: branch.id,
        name: branch.name,
        address: branch.address,
        totalSales,
        customerCount: uniqueCustomers,
        averageTicket: branch.purchases.length > 0 ? totalSales / branch.purchases.length : 0,
        transactionCount: branch.purchases.length,
      };
    }).sort((a, b) => b.totalSales - a.totalSales);

    // Loyalty level distribution
    const loyaltyStats = await prisma.customer.groupBy({
      by: ['loyaltyLevel'],
      _count: {
        id: true,
      },
    });

    res.json({
      success: true,
      metrics: {
        totalCustomers,
        totalBranches,
        totalSales: totalSales._sum.amount || 0,
        totalTransactions: totalSales._count || 0,
        totalPointsRedeemed: totalPointsRedeemed._sum.pointsUsed || 0,
        averageTicket: totalSales._count > 0 
          ? (totalSales._sum.amount || 0) / totalSales._count 
          : 0,
      },
      recentPurchases,
      topCustomers,
      branchPerformance,
      chartData,
      loyaltyStats: loyaltyStats.map(stat => ({
        level: stat.loyaltyLevel,
        count: stat._count.id,
      })),
    });
  } catch (error) {
    console.error('Get admin dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Get customer management data
 */
export const getCustomersData: RequestHandler = async (req, res) => {
  try {
    const { page = 1, limit = 50, search, loyaltyLevel } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const where: any = {};

    if (search) {
      where.OR = [
        {
          user: {
            name: {
              contains: search as string,
              mode: 'insensitive',
            },
          },
        },
        {
          user: {
            email: {
              contains: search as string,
              mode: 'insensitive',
            },
          },
        },
        {
          dni: {
            contains: search as string,
          },
        },
      ];
    }

    if (loyaltyLevel && loyaltyLevel !== 'all') {
      where.loyaltyLevel = loyaltyLevel;
    }

    const [customers, totalCount] = await Promise.all([
      prisma.customer.findMany({
        where,
        include: {
          user: {
            select: { name: true, email: true },
          },
          purchases: {
            select: { id: true },
          },
          redemptions: {
            select: { id: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
      }),
      prisma.customer.count({ where }),
    ]);

    res.json({
      success: true,
      customers,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: totalCount,
        pages: Math.ceil(totalCount / Number(limit)),
      },
    });
  } catch (error) {
    console.error('Get customers data error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Get branches data
 */
export const getBranchesData: RequestHandler = async (req, res) => {
  try {
    const branches = await prisma.branch.findMany({
      include: {
        manager: {
          select: { name: true, email: true },
        },
        purchases: {
          select: {
            amount: true,
            customerId: true,
            purchaseDate: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const branchesWithStats = branches.map(branch => {
      const totalSales = branch.purchases.reduce((sum, p) => sum + p.amount, 0);
      const uniqueCustomers = new Set(branch.purchases.map(p => p.customerId)).size;
      
      // Calculate monthly sales
      const currentMonth = new Date();
      currentMonth.setDate(1);
      currentMonth.setHours(0, 0, 0, 0);
      
      const monthlyPurchases = branch.purchases.filter(p => 
        p.purchaseDate >= currentMonth
      );
      const monthlySales = monthlyPurchases.reduce((sum, p) => sum + p.amount, 0);

      return {
        ...branch,
        stats: {
          totalSales,
          monthlySales,
          customerCount: uniqueCustomers,
          transactionCount: branch.purchases.length,
          monthlyTransactions: monthlyPurchases.length,
          averageTicket: branch.purchases.length > 0 ? totalSales / branch.purchases.length : 0,
        },
      };
    });

    res.json({
      success: true,
      branches: branchesWithStats,
    });
  } catch (error) {
    console.error('Get branches data error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};
