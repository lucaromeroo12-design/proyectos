import { RequestHandler } from 'express';
import prisma from '../services/database';
import { determineLoyaltyLevel, getNextLevelInfo } from '../utils/loyaltyLevels';

/**
 * Get customer dashboard data
 */
export const getCustomerDashboard: RequestHandler = async (req, res) => {
  try {
    if (!req.user?.customer) {
      return res.status(403).json({
        success: false,
        message: 'Customer access required',
      });
    }

    const customer = await prisma.customer.findUnique({
      where: { id: req.user.customer.id },
      include: {
        user: {
          select: { id: true, email: true, name: true },
        },
        purchases: {
          include: {
            branch: true,
          },
          orderBy: { purchaseDate: 'desc' },
          take: 10,
        },
        redemptions: {
          include: {
            benefit: true,
          },
          orderBy: { redeemedAt: 'desc' },
          take: 5,
        },
      },
    });

    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found',
      });
    }

    // Calculate points earned over time for chart
    const pointsHistory = await prisma.purchase.findMany({
      where: { customerId: customer.id },
      select: {
        purchaseDate: true,
        pointsEarned: true,
        amount: true,
      },
      orderBy: { purchaseDate: 'asc' },
    });

    // Group by month for chart
    const monthlyData: { [key: string]: { points: number; spent: number; purchases: number } } = {};
    
    pointsHistory.forEach(purchase => {
      const monthKey = purchase.purchaseDate.toISOString().slice(0, 7); // YYYY-MM
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = { points: 0, spent: 0, purchases: 0 };
      }
      monthlyData[monthKey].points += purchase.pointsEarned;
      monthlyData[monthKey].spent += purchase.amount;
      monthlyData[monthKey].purchases += 1;
    });

    const chartData = Object.entries(monthlyData).map(([month, data]) => ({
      month,
      points: data.points,
      spent: data.spent,
      purchases: data.purchases,
    }));

    // Get next level info
    const nextLevel = getNextLevelInfo(customer.loyaltyLevel, customer.totalSpent);

    res.json({
      success: true,
      customer: {
        id: customer.id,
        name: customer.user.name,
        email: customer.user.email,
        dni: customer.dni,
        points: customer.points,
        loyaltyLevel: customer.loyaltyLevel,
        totalSpent: customer.totalSpent,
        registrationDate: customer.registrationDate,
      },
      recentPurchases: customer.purchases,
      recentRedemptions: customer.redemptions,
      chartData,
      nextLevel,
      stats: {
        totalPurchases: pointsHistory.length,
        totalPointsEarned: pointsHistory.reduce((sum, p) => sum + p.pointsEarned, 0),
        averageTicket: pointsHistory.length > 0 
          ? pointsHistory.reduce((sum, p) => sum + p.amount, 0) / pointsHistory.length 
          : 0,
      },
    });
  } catch (error) {
    console.error('Get customer dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Get customer points history
 */
export const getCustomerPointsHistory: RequestHandler = async (req, res) => {
  try {
    if (!req.user?.customer) {
      return res.status(403).json({
        success: false,
        message: 'Customer access required',
      });
    }

    const purchases = await prisma.purchase.findMany({
      where: { customerId: req.user.customer.id },
      include: {
        branch: {
          select: { name: true },
        },
      },
      orderBy: { purchaseDate: 'desc' },
    });

    const redemptions = await prisma.redemption.findMany({
      where: { customerId: req.user.customer.id },
      include: {
        benefit: {
          select: { title: true },
        },
      },
      orderBy: { redeemedAt: 'desc' },
    });

    // Combine and sort by date
    const history = [
      ...purchases.map(p => ({
        id: p.id,
        date: p.purchaseDate,
        type: 'earned' as const,
        points: p.pointsEarned,
        description: `Compra en ${p.branch.name}`,
        amount: p.amount,
        details: JSON.parse(p.products),
      })),
      ...redemptions.map(r => ({
        id: r.id,
        date: r.redeemedAt,
        type: 'redeemed' as const,
        points: -r.pointsUsed,
        description: `Canje: ${r.benefit.title}`,
        code: r.code,
      })),
    ].sort((a, b) => b.date.getTime() - a.date.getTime());

    res.json({
      success: true,
      history,
    });
  } catch (error) {
    console.error('Get customer points history error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Get available benefits for customer
 */
export const getAvailableBenefits: RequestHandler = async (req, res) => {
  try {
    if (!req.user?.customer) {
      return res.status(403).json({
        success: false,
        message: 'Customer access required',
      });
    }

    const customer = await prisma.customer.findUnique({
      where: { id: req.user.customer.id },
    });

    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found',
      });
    }

    // Get all active benefits
    const benefits = await prisma.benefit.findMany({
      where: {
        isActive: true,
      },
      orderBy: { pointsCost: 'asc' },
    });

    // Categorize benefits
    const available = benefits.filter(b => {
      const levelOrder = { BRONZE: 1, SILVER: 2, GOLD: 3 };
      const customerLevel = levelOrder[customer.loyaltyLevel];
      const benefitLevel = levelOrder[b.minLoyaltyLevel];
      return customerLevel >= benefitLevel;
    });

    const locked = benefits.filter(b => {
      const levelOrder = { BRONZE: 1, SILVER: 2, GOLD: 3 };
      const customerLevel = levelOrder[customer.loyaltyLevel];
      const benefitLevel = levelOrder[b.minLoyaltyLevel];
      return customerLevel < benefitLevel;
    });

    res.json({
      success: true,
      available,
      locked,
      customerPoints: customer.points,
    });
  } catch (error) {
    console.error('Get available benefits error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};
