import { RequestHandler } from 'express';
import { UserRole } from '@prisma/client';
import prisma from '../services/database';
import { hashPassword, comparePassword, generateToken } from '../utils/auth';
import { determineLoyaltyLevel } from '../utils/loyaltyLevels';
import { logAuditEvent } from '../services/auditService';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  name: string;
  dni?: string; // Required for customers
}

export interface AuthResponse {
  success: boolean;
  message: string;
  user?: {
    id: string;
    email: string;
    name: string;
    role: UserRole;
    customer?: any;
    branch?: any;
  };
  token?: string;
}

/**
 * Login endpoint
 */
export const login: RequestHandler = async (req, res) => {
  try {
    const { email, password }: LoginRequest = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required',
      });
    }

    // Find user with related data
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      include: {
        customer: true,
        branch: true,
      },
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
    }

    // Verify password
    const isValidPassword = await comparePassword(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
    }

    // Generate JWT token
    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
    });

    // Log successful login
    await logAuditEvent({
      userId: user.id,
      event: 'USER_LOGIN',
      details: JSON.stringify({ email: user.email, role: user.role }),
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
    });

    const response: AuthResponse = {
      success: true,
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        customer: user.customer,
        branch: user.branch,
      },
      token,
    };

    res.json(response);
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Register endpoint (for customers)
 */
export const register: RequestHandler = async (req, res) => {
  try {
    const { email, password, name, dni }: RegisterRequest = req.body;

    if (!email || !password || !name || !dni) {
      return res.status(400).json({
        success: false,
        message: 'Email, password, name, and DNI are required',
      });
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'Email already registered',
      });
    }

    // Check if DNI already exists
    const existingCustomer = await prisma.customer.findUnique({
      where: { dni },
    });

    if (existingCustomer) {
      return res.status(409).json({
        success: false,
        message: 'DNI already registered',
      });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user and customer in a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          email: email.toLowerCase(),
          password: hashedPassword,
          name,
          role: UserRole.CUSTOMER,
        },
      });

      // Create customer profile
      const customer = await tx.customer.create({
        data: {
          userId: user.id,
          dni,
          points: 0,
          loyaltyLevel: determineLoyaltyLevel(0),
          totalSpent: 0,
        },
      });

      return { user, customer };
    });

    // Generate JWT token
    const token = generateToken({
      userId: result.user.id,
      email: result.user.email,
      role: result.user.role,
    });

    // Log successful registration
    await logAuditEvent({
      userId: result.user.id,
      event: 'USER_REGISTER',
      details: JSON.stringify({ email: result.user.email, dni }),
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
    });

    const response: AuthResponse = {
      success: true,
      message: 'Registration successful',
      user: {
        id: result.user.id,
        email: result.user.email,
        name: result.user.name,
        role: result.user.role,
        customer: result.customer,
      },
      token,
    };

    res.status(201).json(response);
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Get current user profile
 */
export const getProfile: RequestHandler = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }

    const user = await prisma.user.findUnique({
      where: { id: req.user.userId },
      include: {
        customer: true,
        branch: true,
      },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        customer: user.customer,
        branch: user.branch,
      },
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Logout endpoint (mainly for logging purposes)
 */
export const logout: RequestHandler = async (req, res) => {
  try {
    if (req.user) {
      await logAuditEvent({
        userId: req.user.userId,
        event: 'USER_LOGOUT',
        details: JSON.stringify({ email: req.user.email }),
        ipAddress: req.ip,
        userAgent: req.get('User-Agent'),
      });
    }

    res.json({
      success: true,
      message: 'Logout successful',
    });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};
