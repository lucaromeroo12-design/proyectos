import { LoyaltyLevel } from '@prisma/client';

// Loyalty level thresholds (in total spending amount)
export const LOYALTY_THRESHOLDS = {
  BRONZE: 0,
  SILVER: 10000,
  GOLD: 30000,
} as const;

/**
 * Determines loyalty level based on total spent amount
 * @param totalSpent - Total amount spent by customer
 * @returns LoyaltyLevel enum value
 */
export function determineLoyaltyLevel(totalSpent: number): LoyaltyLevel {
  if (totalSpent >= LOYALTY_THRESHOLDS.GOLD) {
    return LoyaltyLevel.GOLD;
  } else if (totalSpent >= LOYALTY_THRESHOLDS.SILVER) {
    return LoyaltyLevel.SILVER;
  } else {
    return LoyaltyLevel.BRONZE;
  }
}

/**
 * Calculates points to earn based on purchase amount
 * Rule: 1 point per $1000 spent (rounded down)
 * @param amount - Purchase amount
 * @returns Points to earn (minimum 0)
 */
export function calculatePoints(amount: number): number {
  if (amount <= 0) return 0;
  return Math.floor(amount / 1000);
}

/**
 * Gets the next loyalty level and remaining amount needed
 * @param currentLevel - Current loyalty level
 * @param totalSpent - Current total spent
 * @returns Next level info or null if already at max level
 */
export function getNextLevelInfo(currentLevel: LoyaltyLevel, totalSpent: number) {
  switch (currentLevel) {
    case LoyaltyLevel.BRONZE:
      return {
        nextLevel: LoyaltyLevel.SILVER,
        amountNeeded: LOYALTY_THRESHOLDS.SILVER - totalSpent,
        threshold: LOYALTY_THRESHOLDS.SILVER,
      };
    case LoyaltyLevel.SILVER:
      return {
        nextLevel: LoyaltyLevel.GOLD,
        amountNeeded: LOYALTY_THRESHOLDS.GOLD - totalSpent,
        threshold: LOYALTY_THRESHOLDS.GOLD,
      };
    case LoyaltyLevel.GOLD:
      return null; // Already at max level
    default:
      return null;
  }
}

/**
 * Gets loyalty level display information
 */
export function getLoyaltyLevelDisplay(level: LoyaltyLevel) {
  switch (level) {
    case LoyaltyLevel.BRONZE:
      return {
        name: 'Bronce',
        color: '#CD7F32',
        benefits: ['Acumulación de puntos estándar', 'Acceso a beneficios básicos'],
      };
    case LoyaltyLevel.SILVER:
      return {
        name: 'Plata',
        color: '#C0C0C0',
        benefits: ['Acumulación de puntos estándar', 'Acceso a beneficios especiales', 'Descuentos exclusivos'],
      };
    case LoyaltyLevel.GOLD:
      return {
        name: 'Oro',
        color: '#FFD700',
        benefits: ['Acumulación de puntos estándar', 'Todos los beneficios VIP', 'Acceso prioritario', 'Regalos exclusivos'],
      };
    default:
      return {
        name: 'Desconocido',
        color: '#888888',
        benefits: [],
      };
  }
}
