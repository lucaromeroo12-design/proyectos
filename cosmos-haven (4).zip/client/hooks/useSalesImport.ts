import { useState } from 'react';
import { SalesImportResponse, SalesPreviewResponse } from '@shared/salesImport';
import { useAuth } from '@/context/AuthContext';

export function useSalesImport() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const previewSales = async (file: File): Promise<SalesPreviewResponse | null> => {
    if (!user || user.role !== 'ADMIN') {
      setError('Se requieren permisos de administrador');
      return null;
    }

    setIsLoading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/admin/sales-import/preview', {
        method: 'POST',
        headers: {
          'x-user-role': user.role
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const result: SalesPreviewResponse = await response.json();
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error desconocido';
      setError(errorMessage);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const processSales = async (file: File): Promise<SalesImportResponse | null> => {
    if (!user || user.role !== 'ADMIN') {
      setError('Se requieren permisos de administrador');
      return null;
    }

    setIsLoading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/admin/sales-import/process', {
        method: 'POST',
        headers: {
          'x-user-role': user.role
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const result: SalesImportResponse = await response.json();
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error desconocido';
      setError(errorMessage);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    previewSales,
    processSales,
    isLoading,
    error
  };
}
