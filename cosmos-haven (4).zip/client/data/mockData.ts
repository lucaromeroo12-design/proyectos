import { Branch, Purchase, Benefit, Redemption, Customer, DashboardMetrics, BranchMetrics } from '@shared/types';

export const mockBranches: Branch[] = [
  { id: 'branch-001', name: 'Sucursal Centro', address: 'Av. Corrientes 1234, CABA', managerId: 'branch-1', isActive: true },
  { id: 'branch-002', name: 'Sucursal Palermo', address: 'Av. Santa Fe 5678, CABA', managerId: 'branch-2', isActive: true },
  { id: 'branch-003', name: 'Sucursal Belgrano', address: 'Av. Cabildo 9876, CABA', managerId: 'branch-3', isActive: true },
];

export const mockCustomers: Customer[] = [
  {
    id: 'customer-1',
    email: 'cliente@demo.com',
    name: 'María González',
    role: 'CUSTOMER',
    dni: '12345678',
    points: 1250,
    loyaltyLevel: 'silver',
    totalSpent: 15000,
    registrationDate: '2023-01-15'
  },
  {
    id: 'customer-2',
    email: 'juan.perez@email.com',
    name: 'Juan Pérez',
    role: 'CUSTOMER',
    dni: '87654321',
    points: 2500,
    loyaltyLevel: 'gold',
    totalSpent: 35000,
    registrationDate: '2022-08-20'
  },
  {
    id: 'customer-3',
    email: 'ana.martinez@email.com',
    name: 'Ana Martínez',
    role: 'CUSTOMER',
    dni: '11223344',
    points: 500,
    loyaltyLevel: 'bronze',
    totalSpent: 5000,
    registrationDate: '2024-01-10'
  }
];

export const mockPurchases: Purchase[] = [
  {
    id: 'purchase-1',
    customerId: 'customer-1',
    branchId: 'branch-001',
    amount: 2500,
    pointsEarned: 125,
    products: ['Producto A', 'Producto B'],
    date: '2024-01-15T10:30:00',
    branch: mockBranches[0]
  },
  {
    id: 'purchase-2',
    customerId: 'customer-2',
    branchId: 'branch-002',
    amount: 5000,
    pointsEarned: 250,
    products: ['Producto Premium'],
    date: '2024-01-14T15:45:00',
    branch: mockBranches[1]
  },
  {
    id: 'purchase-3',
    customerId: 'customer-1',
    branchId: 'branch-001',
    amount: 1800,
    pointsEarned: 90,
    products: ['Producto C', 'Producto D', 'Producto E'],
    date: '2024-01-13T12:20:00',
    branch: mockBranches[0]
  }
];

export const mockBenefits: Benefit[] = [
  {
    id: 'benefit-1',
    title: '10% de descuento',
    description: 'Descuento del 10% en tu próxima compra',
    pointsCost: 500,
    type: 'discount',
    value: '10%',
    isActive: true,
    validUntil: '2024-12-31',
    minLoyaltyLevel: 'bronze'
  },
  {
    id: 'benefit-2',
    title: 'Café gratis',
    description: 'Un café gratis en cualquier sucursal',
    pointsCost: 200,
    type: 'gift',
    value: 'Café gratis',
    isActive: true,
    minLoyaltyLevel: 'bronze'
  },
  {
    id: 'benefit-3',
    title: '20% de descuento VIP',
    description: 'Descuento especial para miembros Gold',
    pointsCost: 1000,
    type: 'discount',
    value: '20%',
    isActive: true,
    validUntil: '2024-12-31',
    minLoyaltyLevel: 'gold'
  }
];

export const mockRedemptions: Redemption[] = [
  {
    id: 'redemption-1',
    customerId: 'customer-1',
    benefitId: 'benefit-1',
    pointsUsed: 500,
    date: '2024-01-10T14:30:00',
    status: 'used',
    benefit: mockBenefits[0]
  }
];

export const mockDashboardMetrics: DashboardMetrics = {
  totalSales: 125000,
  totalCustomers: 150,
  totalPointsRedeemed: 12500,
  averageTicket: 2800,
  topCustomers: mockCustomers.slice(0, 5),
  recentTransactions: mockPurchases.slice(0, 10),
  salesByMonth: [
    { month: 'Ene', sales: 95000 },
    { month: 'Feb', sales: 108000 },
    { month: 'Mar', sales: 125000 },
  ]
};

export const mockBranchMetrics: BranchMetrics = {
  branchId: 'branch-001',
  totalSales: 45000,
  customerCount: 50,
  averageTicket: 2800,
  topCustomers: mockCustomers.slice(0, 3),
  recentSales: mockPurchases.filter(p => p.branchId === 'branch-001'),
  salesByWeek: [
    { week: 'Sem 1', sales: 12000 },
    { week: 'Sem 2', sales: 15000 },
    { week: 'Sem 3', sales: 18000 },
  ]
};

export const getLoyaltyLevelInfo = (level: string) => {
  switch (level) {
    case 'bronze':
      return { name: 'Bronce', color: 'text-loyalty-bronze', bgColor: 'bg-loyalty-bronze/10', minSpent: 0 };
    case 'silver':
      return { name: 'Plata', color: 'text-loyalty-silver', bgColor: 'bg-loyalty-silver/10', minSpent: 10000 };
    case 'gold':
      return { name: 'Oro', color: 'text-loyalty-gold', bgColor: 'bg-loyalty-gold/10', minSpent: 30000 };
    default:
      return { name: 'Bronce', color: 'text-loyalty-bronze', bgColor: 'bg-loyalty-bronze/10', minSpent: 0 };
  }
};

export const getNextLoyaltyLevel = (currentLevel: string, totalSpent: number) => {
  if (currentLevel === 'bronze' && totalSpent < 10000) {
    return { next: 'silver', remaining: 10000 - totalSpent };
  }
  if (currentLevel === 'silver' && totalSpent < 30000) {
    return { next: 'gold', remaining: 30000 - totalSpent };
  }
  return null;
};
