import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { Layout } from "@/components/layout/Layout";
import Auth from "./pages/Auth";
import Configuration from "./pages/Configuration";
import ErrorBoundary from "./components/ErrorBoundary";
import CustomerDashboard from "./pages/customer/EnhancedDashboard";
import BranchDashboard from "./pages/branch/Dashboard";
import AdminDashboard from "./pages/admin/Dashboard";
import SalesImport from "./pages/admin/SalesImport";
import BranchManagement from "./pages/admin/BranchManagement";
import BenefitsManagement from "./pages/admin/BenefitsManagement";
import CustomerManagement from "./pages/admin/CustomerManagement";
import Reports from "./pages/admin/Reports";
import Points from "./pages/customer/Points";
import Benefits from "./pages/customer/Benefits";
import PurchaseHistory from "./pages/customer/PurchaseHistory";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  return user ? <Layout>{children}</Layout> : <Navigate to="/auth" />;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  return user ? <Navigate to="/dashboard" /> : <>{children}</>;
}

function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-muted-foreground mb-2">{title}</h1>
        <p className="text-muted-foreground">Esta página estará disponible próximamente.</p>
        <p className="text-sm text-muted-foreground mt-2">Continúa navegando para explorar las funcionalidades disponibles.</p>
      </div>
    </div>
  );
}

function RoleBasedDashboard() {
  const { user } = useAuth();

  if (!user) return null;

  switch (user.role) {
    case 'CUSTOMER':
      return <CustomerDashboard />;
    case 'BRANCH':
      return <BranchDashboard />;
    case 'ADMIN':
      return <AdminDashboard />;
    default:
      return <CustomerDashboard />;
  }
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/auth" element={<PublicRoute><Auth /></PublicRoute>} />
      <Route path="/" element={<Navigate to="/dashboard" />} />

      {/* Dashboard - Role-based */}
      <Route path="/dashboard" element={<ProtectedRoute><RoleBasedDashboard /></ProtectedRoute>} />
      <Route path="/puntos" element={<ProtectedRoute><Points /></ProtectedRoute>} />
      <Route path="/beneficios" element={<ProtectedRoute><Benefits /></ProtectedRoute>} />
      <Route path="/historial" element={<ProtectedRoute><PurchaseHistory /></ProtectedRoute>} />
      <Route path="/perfil" element={<ProtectedRoute><PlaceholderPage title="Mi Perfil" /></ProtectedRoute>} />

      {/* Branch Routes */}
      <Route path="/ventas" element={<ProtectedRoute><PlaceholderPage title="Registrar Venta" /></ProtectedRoute>} />
      <Route path="/clientes" element={<ProtectedRoute><PlaceholderPage title="Clientes de la Sucursal" /></ProtectedRoute>} />
      <Route path="/estadisticas" element={<ProtectedRoute><PlaceholderPage title="Estadísticas de Ventas" /></ProtectedRoute>} />

      {/* Admin Routes */}
      <Route path="/sucursales" element={<ProtectedRoute><BranchManagement /></ProtectedRoute>} />
      <Route path="/beneficios-admin" element={<ProtectedRoute><BenefitsManagement /></ProtectedRoute>} />
      <Route path="/clientes-admin" element={<ProtectedRoute><CustomerManagement /></ProtectedRoute>} />
      <Route path="/reportes" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
      <Route path="/importar-ventas" element={<ProtectedRoute><SalesImport /></ProtectedRoute>} />
      <Route path="/configuracion" element={<ProtectedRoute><Configuration /></ProtectedRoute>} />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <ErrorBoundary>
          <AuthProvider>
            <BrowserRouter>
              <AppRoutes />
            </BrowserRouter>
          </AuthProvider>
        </ErrorBoundary>
      </TooltipProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

createRoot(document.getElementById("root")!).render(<App />);
