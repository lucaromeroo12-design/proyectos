import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  MapPin, 
  Plus, 
  Edit, 
  Trash2, 
  Users, 
  DollarSign, 
  TrendingUp,
  Building2,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { mockBranches } from '@/data/mockData';
import { Branch } from '@shared/types';

export default function BranchManagement() {
  const [branches, setBranches] = useState<Branch[]>(mockBranches);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);
  const [newBranch, setNewBranch] = useState({
    name: '',
    address: '',
    managerId: ''
  });

  const handleCreateBranch = () => {
    const branch: Branch = {
      id: `branch-${Date.now()}`,
      name: newBranch.name,
      address: newBranch.address,
      managerId: newBranch.managerId || undefined,
      isActive: true
    };
    
    setBranches([...branches, branch]);
    setNewBranch({ name: '', address: '', managerId: '' });
    setIsCreateDialogOpen(false);
  };

  const handleToggleActive = (branchId: string) => {
    setBranches(branches.map(branch => 
      branch.id === branchId 
        ? { ...branch, isActive: !branch.isActive }
        : branch
    ));
  };

  const handleDeleteBranch = (branchId: string) => {
    setBranches(branches.filter(branch => branch.id !== branchId));
  };

  const activeBranches = branches.filter(b => b.isActive).length;
  const totalSales = 125000; // Mock data
  const averagePerformance = 85; // Mock data

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Sucursales</h1>
          <p className="text-muted-foreground">
            Administra las sucursales del sistema de fidelización
          </p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nueva Sucursal
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crear Nueva Sucursal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Nombre de la Sucursal</Label>
                <Input
                  id="name"
                  value={newBranch.name}
                  onChange={(e) => setNewBranch({...newBranch, name: e.target.value})}
                  placeholder="Ej: Sucursal Centro"
                />
              </div>
              <div>
                <Label htmlFor="address">Dirección</Label>
                <Input
                  id="address"
                  value={newBranch.address}
                  onChange={(e) => setNewBranch({...newBranch, address: e.target.value})}
                  placeholder="Ej: Av. Corrientes 1234, CABA"
                />
              </div>
              <div>
                <Label htmlFor="manager">ID del Manager (opcional)</Label>
                <Input
                  id="manager"
                  value={newBranch.managerId}
                  onChange={(e) => setNewBranch({...newBranch, managerId: e.target.value})}
                  placeholder="Ej: manager-001"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleCreateBranch} disabled={!newBranch.name || !newBranch.address}>
                  Crear Sucursal
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Sucursales</p>
                <p className="text-2xl font-bold">{branches.length}</p>
              </div>
              <Building2 className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Sucursales Activas</p>
                <p className="text-2xl font-bold text-success">{activeBranches}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Ventas Totales</p>
                <p className="text-2xl font-bold">${totalSales.toLocaleString()}</p>
              </div>
              <DollarSign className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Rendimiento Promedio</p>
                <p className="text-2xl font-bold">{averagePerformance}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Branches List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Sucursales</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {branches.map((branch) => (
              <div key={branch.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                      branch.isActive ? 'bg-success/10' : 'bg-muted'
                    }`}>
                      <MapPin className={`h-6 w-6 ${
                        branch.isActive ? 'text-success' : 'text-muted-foreground'
                      }`} />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{branch.name}</h3>
                        <Badge variant={branch.isActive ? "default" : "secondary"}>
                          {branch.isActive ? 'Activa' : 'Inactiva'}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground">{branch.address}</p>
                      {branch.managerId && (
                        <p className="text-sm text-muted-foreground">
                          Manager ID: {branch.managerId}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Mock performance metrics */}
                    <div className="text-right mr-4">
                      <p className="text-sm font-medium">$45,000</p>
                      <p className="text-xs text-muted-foreground">Ventas del mes</p>
                    </div>
                    <div className="text-right mr-4">
                      <p className="text-sm font-medium">50</p>
                      <p className="text-xs text-muted-foreground">Clientes</p>
                    </div>
                    
                    <div className="flex items-center gap-1">
                      <Label htmlFor={`active-${branch.id}`} className="text-sm">
                        Activa
                      </Label>
                      <Switch
                        id={`active-${branch.id}`}
                        checked={branch.isActive}
                        onCheckedChange={() => handleToggleActive(branch.id)}
                      />
                    </div>
                    
                    <Button variant="ghost" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleDeleteBranch(branch.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {branches.length === 0 && (
            <div className="text-center py-8">
              <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay sucursales</h3>
              <p className="text-muted-foreground mb-4">
                Comienza creando tu primera sucursal
              </p>
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Crear Sucursal
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Performance Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Rendimiento por Sucursal</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {branches.filter(b => b.isActive).map((branch, index) => {
              const performance = 75 + Math.random() * 25; // Mock performance
              const sales = 30000 + Math.random() * 20000; // Mock sales
              
              return (
                <div key={branch.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-bold">{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-medium">{branch.name}</p>
                      <p className="text-sm text-muted-foreground">{branch.address}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="font-medium">${sales.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</p>
                      <p className="text-xs text-muted-foreground">Ventas</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{performance.toFixed(1)}%</p>
                      <p className="text-xs text-muted-foreground">Rendimiento</p>
                    </div>
                    <div className="w-24">
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${performance}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
