import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  BarChart3,
  Users,
  TrendingUp,
  Gift,
  MapPin,
  DollarSign,
  Award,
  Download,
  Loader2
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Admin, LoyaltyLevel } from '@shared/types';

interface DashboardData {
  metrics: {
    totalCustomers: number;
    totalBranches: number;
    totalSales: number;
    totalTransactions: number;
    totalPointsRedeemed: number;
    averageTicket: number;
  };
  recentPurchases: Array<{
    id: string;
    amount: number;
    purchaseDate: string;
    pointsEarned: number;
    customer: {
      user: { name: string; email: string };
    };
    branch: { name: string; address: string };
  }>;
  topCustomers: Array<{
    id: string;
    points: number;
    loyaltyLevel: LoyaltyLevel;
    totalSpent: number;
    user: { name: string; email: string };
  }>;
  branchPerformance: Array<{
    id: string;
    name: string;
    address: string;
    totalSales: number;
    customerCount: number;
    averageTicket: number;
    transactionCount: number;
  }>;
  chartData: Array<{
    month: string;
    sales: number;
    transactions: number;
  }>;
  loyaltyStats: Array<{
    level: LoyaltyLevel;
    count: number;
  }>;
}

const getLoyaltyLevelInfo = (level: LoyaltyLevel) => {
  switch (level) {
    case 'BRONZE':
      return { name: 'Bronce', color: 'text-amber-600 bg-amber-50', chartColor: '#d97706' };
    case 'SILVER':
      return { name: 'Plata', color: 'text-gray-600 bg-gray-50', chartColor: '#6b7280' };
    case 'GOLD':
      return { name: 'Oro', color: 'text-yellow-600 bg-yellow-50', chartColor: '#ca8a04' };
    default:
      return { name: 'Bronce', color: 'text-amber-600 bg-amber-50', chartColor: '#d97706' };
  }
};

export default function AdminDashboard() {
  const { user, token } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const admin = user as Admin;

  if (!admin || admin.role !== 'ADMIN') {
    return <div>Error: No se pudo cargar la información del administrador</div>;
  }

  const fetchDashboardData = React.useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch('/api/admin/dashboard', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();

      console.log('Dashboard API response:', result);

      if (result.success) {
        // Validate the structure of the response
        const validatedData = {
          metrics: result.metrics || {},
          chartData: Array.isArray(result.chartData) ? result.chartData : [],
          topCustomers: Array.isArray(result.topCustomers) ? result.topCustomers : [],
          branchPerformance: Array.isArray(result.branchPerformance) ? result.branchPerformance : [],
          recentPurchases: Array.isArray(result.recentPurchases) ? result.recentPurchases : [],
          loyaltyStats: Array.isArray(result.loyaltyStats) ? result.loyaltyStats : [],
        };

        console.log('Validated data:', validatedData);
        setData(validatedData);
      } else {
        throw new Error(result.message || 'Error al cargar datos');
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    if (token) {
      fetchDashboardData();
    }
  }, [fetchDashboardData, token]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="flex items-center gap-2">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Cargando dashboard...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>
          Error al cargar el dashboard: {error}
          <Button
            variant="outline"
            size="sm"
            className="mt-2"
            onClick={fetchDashboardData}
          >
            Reintentar
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (!data) {
    return <div>No hay datos disponibles</div>;
  }

  // Ensure all arrays exist and are arrays to prevent rendering errors
  const safeData = {
    ...data,
    chartData: Array.isArray(data.chartData) ? data.chartData.filter(item =>
      item && typeof item === 'object' && typeof item.month === 'string' && typeof item.sales === 'number'
    ) : [],
    topCustomers: Array.isArray(data.topCustomers) ? data.topCustomers.filter(customer =>
      customer && typeof customer === 'object' && customer.id && typeof customer.points === 'number'
    ) : [],
    branchPerformance: Array.isArray(data.branchPerformance) ? data.branchPerformance.filter(branch =>
      branch && typeof branch === 'object' && branch.id && typeof branch.name === 'string'
    ) : [],
    recentPurchases: Array.isArray(data.recentPurchases) ? data.recentPurchases.filter(purchase =>
      purchase && typeof purchase === 'object' && purchase.id && typeof purchase.amount === 'number'
    ) : [],
    loyaltyStats: Array.isArray(data.loyaltyStats) ? data.loyaltyStats.filter(stat =>
      stat && typeof stat === 'object' && stat.level && typeof stat.count === 'number'
    ) : [],
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Panel de Administración</h1>
          <p className="text-muted-foreground">Vista general del sistema de fidelización</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar Datos
          </Button>
          <Button className="gap-2">
            <Gift className="h-4 w-4" />
            Crear Beneficio
          </Button>
        </div>
      </div>

      {/* Global Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventas Totales</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${typeof safeData.metrics?.totalSales === 'number' ? safeData.metrics.totalSales.toLocaleString() : '0'}
            </div>
            <p className="text-xs text-muted-foreground">
              {typeof safeData.metrics?.totalTransactions === 'number' ? safeData.metrics.totalTransactions : 0} transacciones
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clientes</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {typeof safeData.metrics?.totalCustomers === 'number' ? safeData.metrics.totalCustomers : 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Clientes registrados
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Puntos Canjeados</CardTitle>
            <Award className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {typeof safeData.metrics?.totalPointsRedeemed === 'number' ? safeData.metrics.totalPointsRedeemed.toLocaleString() : '0'}
            </div>
            <p className="text-xs text-muted-foreground">
              Este mes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ticket Promedio</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${typeof safeData.metrics?.averageTicket === 'number' ? Math.round(safeData.metrics.averageTicket).toLocaleString() : '0'}
            </div>
            <p className="text-xs text-muted-foreground">
              Promedio por transacción
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts and Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ventas Mensuales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {safeData.chartData.length > 0 ? safeData.chartData.map((month, index) => (
                <div key={`chart-month-${index}-${month.month || 'unknown'}`} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{typeof month.month === 'string' ? month.month : `Mes ${index + 1}`}</span>
                    <span className="font-medium">${typeof month.sales === 'number' ? month.sales.toLocaleString() : '0'}</span>
                  </div>
                  <Progress
                    value={safeData.chartData.length > 0 && typeof month.sales === 'number' ?
                      (month.sales / Math.max(...safeData.chartData.filter(m => typeof m.sales === 'number').map(m => m.sales))) * 100 : 0}
                    className="h-2"
                  />
                </div>
              )) : (
                <div className="text-center text-muted-foreground">No hay datos de ventas mensuales</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Clientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {safeData.topCustomers.length > 0 ? safeData.topCustomers.slice(0, 5).map((customer, index) => {
                const loyaltyInfo = getLoyaltyLevelInfo(customer.loyaltyLevel);
                return (
                  <div key={`top-customer-${customer.id}-${index}`} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-bold">{index + 1}</span>
                      </div>
                      <div>
                        <p className="font-medium">
                          {typeof customer.user?.name === 'string' ? customer.user.name : 'Usuario desconocido'}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {typeof customer.points === 'number' ? customer.points : 0} puntos • ${typeof customer.totalSpent === 'number' ? customer.totalSpent.toLocaleString() : '0'} gastado
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className={loyaltyInfo.color}>
                      {loyaltyInfo.name}
                    </Badge>
                  </div>
                );
              }) : (
                <div className="text-center text-muted-foreground">No hay datos de clientes</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Branch Performance and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Rendimiento por Sucursal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {safeData.branchPerformance.length > 0 ? safeData.branchPerformance.map((branch) => (
                <div key={`branch-performance-${branch.id}`} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">{typeof branch.name === 'string' ? branch.name : 'Sucursal sin nombre'}</p>
                      <p className="text-sm text-muted-foreground">{typeof branch.address === 'string' ? branch.address : 'Direcci��n no disponible'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${typeof branch.totalSales === 'number' ? branch.totalSales.toLocaleString() : '0'}</p>
                    <p className="text-sm text-muted-foreground">{typeof branch.customerCount === 'number' ? branch.customerCount : 0} clientes</p>
                  </div>
                </div>
              )) : (
                <div className="text-center text-muted-foreground">No hay datos de sucursales</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Actividad Reciente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {safeData.recentPurchases.length > 0 ? safeData.recentPurchases.slice(0, 5).map((purchase) => (
                <div key={`recent-purchase-${purchase.id}`} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">
                      Nueva venta - {typeof purchase.branch?.name === 'string' ? purchase.branch.name : 'Sucursal desconocida'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(purchase.purchaseDate).toLocaleDateString()} • {typeof purchase.customer?.user?.name === 'string' ? purchase.customer.user.name : 'Cliente desconocido'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${typeof purchase.amount === 'number' ? purchase.amount.toLocaleString() : '0'}</p>
                    <p className="text-sm text-primary">+{typeof purchase.pointsEarned === 'number' ? purchase.pointsEarned : 0} puntos</p>
                  </div>
                </div>
              )) : (
                <div className="text-center text-muted-foreground">No hay compras recientes</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Loyalty Level Distribution */}
      {safeData.loyaltyStats.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Distribución de Niveles de Fidelidad</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              {safeData.loyaltyStats.map((stat, index) => {
                // Add comprehensive safety check for stat object
                if (!stat || typeof stat !== 'object' || typeof stat.level !== 'string' || typeof stat.count !== 'number') {
                  console.warn('Invalid loyalty stat:', stat);
                  return null;
                }

                try {
                  const loyaltyInfo = getLoyaltyLevelInfo(stat.level);
                  return (
                    <div key={`loyalty-stat-${stat.level}-${index}`} className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold mb-2">{stat.count}</div>
                      <Badge variant="outline" className={loyaltyInfo.color}>
                        {loyaltyInfo.name}
                      </Badge>
                    </div>
                  );
                } catch (error) {
                  console.error('Error rendering loyalty stat:', error, stat);
                  return null;
                }
              }).filter(Boolean)}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Acciones Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Gift className="h-6 w-6" />
              <span className="text-sm">Gestionar Beneficios</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <MapPin className="h-6 w-6" />
              <span className="text-sm">Ver Sucursales</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Users className="h-6 w-6" />
              <span className="text-sm">Gestionar Clientes</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <BarChart3 className="h-6 w-6" />
              <span className="text-sm">Ver Reportes</span>
            </Button>
          </div>
        </CardContent>
        </Card>
    </div>
  );
}
