import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  Search, 
  Filter, 
  Download, 
  Award, 
  DollarSign, 
  Calendar,
  TrendingUp,
  Mail,
  Phone,
  MapPin,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';
import { mockCustomers, mockPurchases, getLoyaltyLevelInfo } from '@/data/mockData';
import { Customer, Purchase } from '@shared/types';

export default function CustomerManagement() {
  const [customers, setCustomers] = useState<Customer[]>(mockCustomers);
  const [searchTerm, setSearchTerm] = useState('');
  const [loyaltyFilter, setLoyaltyFilter] = useState<string>('all');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.dni.includes(searchTerm);
    
    const matchesLoyalty = loyaltyFilter === 'all' || customer.loyaltyLevel === loyaltyFilter;
    
    return matchesSearch && matchesLoyalty;
  });

  const handleViewCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsDetailDialogOpen(true);
  };

  const customerPurchases = selectedCustomer 
    ? mockPurchases.filter(p => p.customerId === selectedCustomer.id)
    : [];

  const totalCustomers = customers.length;
  const bronzeCustomers = customers.filter(c => c.loyaltyLevel === 'bronze').length;
  const silverCustomers = customers.filter(c => c.loyaltyLevel === 'silver').length;
  const goldCustomers = customers.filter(c => c.loyaltyLevel === 'gold').length;
  const averagePoints = Math.floor(customers.reduce((sum, c) => sum + c.points, 0) / customers.length);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Clientes</h1>
          <p className="text-muted-foreground">
            Administra la base de datos de clientes del programa de fidelización
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Clientes</p>
                <p className="text-2xl font-bold">{totalCustomers}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Bronce</p>
                <p className="text-2xl font-bold text-loyalty-bronze">{bronzeCustomers}</p>
              </div>
              <Award className="h-8 w-8 text-loyalty-bronze" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Plata</p>
                <p className="text-2xl font-bold text-loyalty-silver">{silverCustomers}</p>
              </div>
              <Award className="h-8 w-8 text-loyalty-silver" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Oro</p>
                <p className="text-2xl font-bold text-loyalty-gold">{goldCustomers}</p>
              </div>
              <Award className="h-8 w-8 text-loyalty-gold" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Promedio</p>
                <p className="text-2xl font-bold">{averagePoints}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nombre, email o DNI..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <Select value={loyaltyFilter} onValueChange={setLoyaltyFilter}>
                <SelectTrigger className="w-48">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <SelectValue placeholder="Filtrar por nivel" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los niveles</SelectItem>
                  <SelectItem value="bronze">Bronce</SelectItem>
                  <SelectItem value="silver">Plata</SelectItem>
                  <SelectItem value="gold">Oro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Clientes ({filteredCustomers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Cliente</th>
                  <th className="text-left p-3">DNI</th>
                  <th className="text-left p-3">Nivel</th>
                  <th className="text-right p-3">Puntos</th>
                  <th className="text-right p-3">Gasto Total</th>
                  <th className="text-left p-3">Registro</th>
                  <th className="text-center p-3">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((customer) => {
                  const loyaltyInfo = getLoyaltyLevelInfo(customer.loyaltyLevel);
                  
                  return (
                    <tr key={customer.id} className="border-b hover:bg-muted/50">
                      <td className="p-3">
                        <div>
                          <p className="font-medium">{customer.name}</p>
                          <p className="text-sm text-muted-foreground">{customer.email}</p>
                        </div>
                      </td>
                      <td className="p-3">
                        <span className="font-mono text-sm">{customer.dni}</span>
                      </td>
                      <td className="p-3">
                        <Badge className={`${loyaltyInfo.bgColor} ${loyaltyInfo.color}`}>
                          {loyaltyInfo.name}
                        </Badge>
                      </td>
                      <td className="p-3 text-right">
                        <span className="font-bold text-primary">{customer.points.toLocaleString()}</span>
                      </td>
                      <td className="p-3 text-right">
                        <span className="font-medium">${customer.totalSpent.toLocaleString()}</span>
                      </td>
                      <td className="p-3">
                        <span className="text-sm text-muted-foreground">
                          {new Date(customer.registrationDate).toLocaleDateString()}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex justify-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleViewCustomer(customer)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {filteredCustomers.length === 0 && (
            <div className="text-center py-8">
              <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No se encontraron clientes</h3>
              <p className="text-muted-foreground">
                Intenta ajustar los filtros de búsqueda
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Customer Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalles del Cliente</DialogTitle>
          </DialogHeader>
          
          {selectedCustomer && (
            <Tabs defaultValue="info" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="info">Información</TabsTrigger>
                <TabsTrigger value="purchases">Compras</TabsTrigger>
                <TabsTrigger value="points">Puntos</TabsTrigger>
              </TabsList>
              
              <TabsContent value="info" className="space-y-4">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Nombre Completo</label>
                      <p className="text-lg font-semibold">{selectedCustomer.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Email</label>
                      <p className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        {selectedCustomer.email}
                      </p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">DNI</label>
                      <p className="font-mono">{selectedCustomer.dni}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Nivel de Fidelidad</label>
                      <div className="flex items-center gap-2">
                        <Badge className={`${getLoyaltyLevelInfo(selectedCustomer.loyaltyLevel).bgColor} ${getLoyaltyLevelInfo(selectedCustomer.loyaltyLevel).color}`}>
                          {getLoyaltyLevelInfo(selectedCustomer.loyaltyLevel).name}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Fecha de Registro</label>
                      <p className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {new Date(selectedCustomer.registrationDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Estado</label>
                      <Badge variant="default">Activo</Badge>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 mt-6">
                  <Card>
                    <CardContent className="pt-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-primary">{selectedCustomer.points}</p>
                        <p className="text-sm text-muted-foreground">Puntos Disponibles</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold">${selectedCustomer.totalSpent.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">Gasto Total</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold">{customerPurchases.length}</p>
                        <p className="text-sm text-muted-foreground">Compras Realizadas</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="purchases" className="space-y-4">
                <div className="space-y-3">
                  {customerPurchases.map((purchase) => (
                    <div key={purchase.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">Compra #{purchase.id.slice(-6)}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(purchase.date).toLocaleDateString()} - {purchase.branch?.name}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Productos: {purchase.products.join(', ')}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">${purchase.amount.toLocaleString()}</p>
                          <p className="text-sm text-primary">+{purchase.pointsEarned} puntos</p>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {customerPurchases.length === 0 && (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">No hay compras registradas</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="points" className="space-y-4">
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Resumen de Puntos</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span>Puntos Ganados Totales:</span>
                        <span className="font-bold">
                          {customerPurchases.reduce((sum, p) => sum + p.pointsEarned, 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Puntos Canjeados:</span>
                        <span className="font-bold">
                          {customerPurchases.reduce((sum, p) => sum + p.pointsEarned, 0) - selectedCustomer.points}
                        </span>
                      </div>
                      <div className="flex justify-between border-t pt-2">
                        <span>Puntos Disponibles:</span>
                        <span className="font-bold text-primary">{selectedCustomer.points}</span>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Próximo Nivel</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {selectedCustomer.loyaltyLevel === 'gold' ? (
                        <p className="text-center text-muted-foreground">
                          Ya alcanzaste el nivel máximo
                        </p>
                      ) : (
                        <div className="space-y-3">
                          <p>Para alcanzar el siguiente nivel necesitas:</p>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Progreso</span>
                              <span>75%</span>
                            </div>
                            <div className="w-full bg-muted rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full w-3/4" />
                            </div>
                            <p className="text-sm text-muted-foreground">
                              $2,500 más en compras
                            </p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
