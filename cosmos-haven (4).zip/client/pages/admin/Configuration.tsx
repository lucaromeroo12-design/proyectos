import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Settings,
  Users,
  Shield,
  Database,
  Bell,
  Award,
  MapPin,
  Mail,
  Lock,
  Download,
  Upload,
  Trash2,
  Save,
  RefreshCw,
  Info
} from 'lucide-react';

export default function AdminConfiguration() {
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [systemSettings, setSystemSettings] = useState({
    companyName: 'FidelityApp',
    companyLogo: '',
    supportEmail: 'soporte@fidelityapp.com',
    maintenanceMode: false,
    allowRegistrations: true,
    maxPointsPerPurchase: 1000,
    pointsExpirationMonths: 12,
  });

  const [loyaltyConfig, setLoyaltyConfig] = useState({
    bronzeThreshold: 0,
    silverThreshold: 10000,
    goldThreshold: 30000,
    pointsPerDollar: 1,
    bonusMultiplier: {
      bronze: 1,
      silver: 1.2,
      gold: 1.5,
    },
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: false,
    welcomeEmails: true,
    purchaseConfirmations: true,
    pointsExpiration: true,
    promotionalEmails: false,
  });

  const [securitySettings, setSecuritySettings] = useState({
    sessionTimeout: 30,
    maxLoginAttempts: 5,
    requireStrongPasswords: true,
    twoFactorAuth: false,
    passwordExpiration: 90,
  });

  const handleSave = async (section: string) => {
    setSaveStatus('saving');
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (error) {
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const getSaveButtonText = () => {
    switch (saveStatus) {
      case 'saving': return 'Guardando...';
      case 'saved': return 'Guardado ✓';
      case 'error': return 'Error al guardar';
      default: return 'Guardar cambios';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Configuración del Sistema</h1>
          <p className="text-muted-foreground">Gestiona la configuración global de la aplicación</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Exportar Configuración
        </Button>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="general" className="gap-2">
            <Settings className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="loyalty" className="gap-2">
            <Award className="h-4 w-4" />
            Fidelidad
          </TabsTrigger>
          <TabsTrigger value="users" className="gap-2">
            <Users className="h-4 w-4" />
            Usuarios
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2">
            <Bell className="h-4 w-4" />
            Notificaciones
          </TabsTrigger>
          <TabsTrigger value="security" className="gap-2">
            <Shield className="h-4 w-4" />
            Seguridad
          </TabsTrigger>
          <TabsTrigger value="data" className="gap-2">
            <Database className="h-4 w-4" />
            Datos
          </TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuración General</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Nombre de la Empresa</Label>
                    <Input
                      id="companyName"
                      value={systemSettings.companyName}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, companyName: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supportEmail">Email de Soporte</Label>
                    <Input
                      id="supportEmail"
                      type="email"
                      value={systemSettings.supportEmail}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, supportEmail: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Modo de Mantenimiento</Label>
                      <p className="text-sm text-muted-foreground">
                        Deshabilita el acceso a la aplicación para mantenimiento
                      </p>
                    </div>
                    <Switch
                      checked={systemSettings.maintenanceMode}
                      onCheckedChange={(checked) => setSystemSettings(prev => ({ ...prev, maintenanceMode: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Permitir Nuevos Registros</Label>
                      <p className="text-sm text-muted-foreground">
                        Permite que nuevos usuarios se registren en la aplicación
                      </p>
                    </div>
                    <Switch
                      checked={systemSettings.allowRegistrations}
                      onCheckedChange={(checked) => setSystemSettings(prev => ({ ...prev, allowRegistrations: checked }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="maxPoints">Máximo de Puntos por Compra</Label>
                    <Input
                      id="maxPoints"
                      type="number"
                      value={systemSettings.maxPointsPerPurchase}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, maxPointsPerPurchase: parseInt(e.target.value) }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pointsExpiration">Expiración de Puntos (meses)</Label>
                    <Input
                      id="pointsExpiration"
                      type="number"
                      value={systemSettings.pointsExpirationMonths}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, pointsExpirationMonths: parseInt(e.target.value) }))}
                    />
                  </div>
                </div>

                <Button onClick={() => handleSave('general')} disabled={saveStatus === 'saving'}>
                  <Save className="h-4 w-4 mr-2" />
                  {getSaveButtonText()}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Loyalty Settings */}
        <TabsContent value="loyalty">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuración de Niveles de Fidelidad</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Los cambios en los umbrales de fidelidad afectarán a todos los clientes existentes.
                  </AlertDescription>
                </Alert>

                <div className="grid gap-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="text-amber-600 bg-amber-50">Bronce</Badge>
                      <span className="font-medium">Nivel Inicial</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      $0 - ${loyaltyConfig.silverThreshold.toLocaleString()}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="text-gray-600 bg-gray-50">Plata</Badge>
                      <div className="space-y-2">
                        <Label htmlFor="silverThreshold">Umbral Nivel Plata</Label>
                        <Input
                          id="silverThreshold"
                          type="number"
                          value={loyaltyConfig.silverThreshold}
                          onChange={(e) => setLoyaltyConfig(prev => ({ ...prev, silverThreshold: parseInt(e.target.value) }))}
                          className="w-32"
                        />
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Multiplicador: x{loyaltyConfig.bonusMultiplier.silver}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="text-yellow-600 bg-yellow-50">Oro</Badge>
                      <div className="space-y-2">
                        <Label htmlFor="goldThreshold">Umbral Nivel Oro</Label>
                        <Input
                          id="goldThreshold"
                          type="number"
                          value={loyaltyConfig.goldThreshold}
                          onChange={(e) => setLoyaltyConfig(prev => ({ ...prev, goldThreshold: parseInt(e.target.value) }))}
                          className="w-32"
                        />
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Multiplicador: x{loyaltyConfig.bonusMultiplier.gold}
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Configuración de Puntos</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="pointsPerDollar">Puntos por cada $1000 gastados</Label>
                      <Input
                        id="pointsPerDollar"
                        type="number"
                        value={loyaltyConfig.pointsPerDollar}
                        onChange={(e) => setLoyaltyConfig(prev => ({ ...prev, pointsPerDollar: parseInt(e.target.value) }))}
                      />
                    </div>
                  </div>
                </div>

                <Button onClick={() => handleSave('loyalty')} disabled={saveStatus === 'saving'}>
                  <Save className="h-4 w-4 mr-2" />
                  {getSaveButtonText()}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* User Management */}
        <TabsContent value="users">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Gestión de Usuarios y Roles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">Usuarios por Rol</h3>
                  <Button variant="outline" className="gap-2">
                    <Users className="h-4 w-4" />
                    Crear Usuario
                  </Button>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold">45</div>
                        <div className="text-sm text-muted-foreground">Administradores</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold">12</div>
                        <div className="text-sm text-muted-foreground">Gerentes de Sucursal</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold">1,234</div>
                        <div className="text-sm text-muted-foreground">Clientes</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Permisos por Rol</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Administrador</div>
                        <div className="text-sm text-muted-foreground">Acceso completo al sistema</div>
                      </div>
                      <Badge>Activo</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Gerente de Sucursal</div>
                        <div className="text-sm text-muted-foreground">Gestión de sucursal y ventas</div>
                      </div>
                      <Badge>Activo</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Cliente</div>
                        <div className="text-sm text-muted-foreground">Acceso a programa de fidelidad</div>
                      </div>
                      <Badge>Activo</Badge>
                    </div>
                  </div>
                </div>

                <Button onClick={() => handleSave('users')} disabled={saveStatus === 'saving'}>
                  <Save className="h-4 w-4 mr-2" />
                  {getSaveButtonText()}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuración de Notificaciones</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Canales de Notificación</h3>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Notificaciones por Email</Label>
                      <p className="text-sm text-muted-foreground">Enviar notificaciones via correo electrónico</p>
                    </div>
                    <Switch
                      checked={notificationSettings.emailNotifications}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, emailNotifications: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Notificaciones por SMS</Label>
                      <p className="text-sm text-muted-foreground">Enviar notificaciones via mensaje de texto</p>
                    </div>
                    <Switch
                      checked={notificationSettings.smsNotifications}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, smsNotifications: checked }))}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Tipos de Notificaciones</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label>Emails de Bienvenida</Label>
                        <p className="text-sm text-muted-foreground">Enviar email al registrar nuevos usuarios</p>
                      </div>
                      <Switch
                        checked={notificationSettings.welcomeEmails}
                        onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, welcomeEmails: checked }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label>Confirmaciones de Compra</Label>
                        <p className="text-sm text-muted-foreground">Confirmar compras y puntos ganados</p>
                      </div>
                      <Switch
                        checked={notificationSettings.purchaseConfirmations}
                        onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, purchaseConfirmations: checked }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label>Expiración de Puntos</Label>
                        <p className="text-sm text-muted-foreground">Avisar cuando los puntos están por expirar</p>
                      </div>
                      <Switch
                        checked={notificationSettings.pointsExpiration}
                        onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, pointsExpiration: checked }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label>Emails Promocionales</Label>
                        <p className="text-sm text-muted-foreground">Enviar ofertas y promociones especiales</p>
                      </div>
                      <Switch
                        checked={notificationSettings.promotionalEmails}
                        onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, promotionalEmails: checked }))}
                      />
                    </div>
                  </div>
                </div>

                <Button onClick={() => handleSave('notifications')} disabled={saveStatus === 'saving'}>
                  <Save className="h-4 w-4 mr-2" />
                  {getSaveButtonText()}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Security */}
        <TabsContent value="security">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuración de Seguridad</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    Los cambios en la configuración de seguridad afectarán a todos los usuarios.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Autenticación</h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="sessionTimeout">Tiempo de Sesión (minutos)</Label>
                      <Input
                        id="sessionTimeout"
                        type="number"
                        value={securitySettings.sessionTimeout}
                        onChange={(e) => setSecuritySettings(prev => ({ ...prev, sessionTimeout: parseInt(e.target.value) }))}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="maxAttempts">Máximo Intentos de Login</Label>
                      <Input
                        id="maxAttempts"
                        type="number"
                        value={securitySettings.maxLoginAttempts}
                        onChange={(e) => setSecuritySettings(prev => ({ ...prev, maxLoginAttempts: parseInt(e.target.value) }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label>Autenticación de Dos Factores</Label>
                        <p className="text-sm text-muted-foreground">Requerir 2FA para administradores</p>
                      </div>
                      <Switch
                        checked={securitySettings.twoFactorAuth}
                        onCheckedChange={(checked) => setSecuritySettings(prev => ({ ...prev, twoFactorAuth: checked }))}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Políticas de Contraseña</h3>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label>Contraseñas Seguras</Label>
                        <p className="text-sm text-muted-foreground">Requerir mayúsculas, números y símbolos</p>
                      </div>
                      <Switch
                        checked={securitySettings.requireStrongPasswords}
                        onCheckedChange={(checked) => setSecuritySettings(prev => ({ ...prev, requireStrongPasswords: checked }))}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="passwordExpiration">Expiración de Contraseña (días)</Label>
                      <Input
                        id="passwordExpiration"
                        type="number"
                        value={securitySettings.passwordExpiration}
                        onChange={(e) => setSecuritySettings(prev => ({ ...prev, passwordExpiration: parseInt(e.target.value) }))}
                      />
                    </div>
                  </div>
                </div>

                <Button onClick={() => handleSave('security')} disabled={saveStatus === 'saving'}>
                  <Save className="h-4 w-4 mr-2" />
                  {getSaveButtonText()}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Data Management */}
        <TabsContent value="data">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Gestión de Datos</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Respaldo de Datos</h3>
                    
                    <div className="space-y-3">
                      <Button className="w-full gap-2">
                        <Download className="h-4 w-4" />
                        Crear Respaldo Completo
                      </Button>
                      
                      <Button variant="outline" className="w-full gap-2">
                        <Download className="h-4 w-4" />
                        Exportar Datos de Clientes
                      </Button>
                      
                      <Button variant="outline" className="w-full gap-2">
                        <Download className="h-4 w-4" />
                        Exportar Datos de Ventas
                      </Button>
                    </div>

                    <div className="text-sm text-muted-foreground">
                      <p>Último respaldo: Hace 2 días</p>
                      <p>Próximo respaldo automático: En 5 días</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Importación de Datos</h3>
                    
                    <div className="space-y-3">
                      <Button variant="outline" className="w-full gap-2">
                        <Upload className="h-4 w-4" />
                        Importar Datos de Clientes
                      </Button>
                      
                      <Button variant="outline" className="w-full gap-2">
                        <Upload className="h-4 w-4" />
                        Importar Datos de Productos
                      </Button>
                      
                      <Button variant="outline" className="w-full gap-2">
                        <Upload className="h-4 w-4" />
                        Restaurar desde Respaldo
                      </Button>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-destructive">Zona de Peligro</h3>
                  <Alert variant="destructive">
                    <Trash2 className="h-4 w-4" />
                    <AlertDescription>
                      Las siguientes acciones son irreversibles. Proceda con extrema precaución.
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Button variant="destructive" className="gap-2">
                      <Trash2 className="h-4 w-4" />
                      Limpiar Datos de Prueba
                    </Button>
                    
                    <Button variant="destructive" className="gap-2">
                      <RefreshCw className="h-4 w-4" />
                      Reiniciar Sistema
                    </Button>
                  </div>
                </div>

                <Button onClick={() => handleSave('data')} disabled={saveStatus === 'saving'}>
                  <Save className="h-4 w-4 mr-2" />
                  {getSaveButtonText()}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
