import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  BarChart3, 
  Users, 
  TrendingUp, 
  Gift, 
  MapPin, 
  DollarSign,
  Award,
  Download,
  Loader2
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Admin, LoyaltyLevel } from '@shared/types';

interface DashboardData {
  metrics: {
    totalCustomers: number;
    totalBranches: number;
    totalSales: number;
    totalTransactions: number;
    totalPointsRedeemed: number;
    averageTicket: number;
  };
  recentPurchases: Array<{
    id: string;
    amount: number;
    purchaseDate: string;
    pointsEarned: number;
    customer: {
      user: { name: string; email: string };
    };
    branch: { name: string; address: string };
  }>;
  topCustomers: Array<{
    id: string;
    points: number;
    loyaltyLevel: LoyaltyLevel;
    totalSpent: number;
    user: { name: string; email: string };
  }>;
  branchPerformance: Array<{
    id: string;
    name: string;
    address: string;
    totalSales: number;
    customerCount: number;
    averageTicket: number;
    transactionCount: number;
  }>;
  chartData: Array<{
    month: string;
    sales: number;
    transactions: number;
  }>;
  loyaltyStats: Array<{
    level: LoyaltyLevel;
    count: number;
  }>;
}

const getLoyaltyLevelInfo = (level: LoyaltyLevel) => {
  switch (level) {
    case 'BRONZE':
      return { name: 'Bronce', color: 'text-amber-600 bg-amber-50', chartColor: '#d97706' };
    case 'SILVER':
      return { name: 'Plata', color: 'text-gray-600 bg-gray-50', chartColor: '#6b7280' };
    case 'GOLD':
      return { name: 'Oro', color: 'text-yellow-600 bg-yellow-50', chartColor: '#ca8a04' };
    default:
      return { name: 'Bronce', color: 'text-amber-600 bg-amber-50', chartColor: '#d97706' };
  }
};

export default function RealAdminDashboard() {
  const { user, token } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const admin = user as Admin;

  if (!admin || admin.role !== 'ADMIN') {
    return <div>Error: No se pudo cargar la información del administrador</div>;
  }

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch('/api/admin/dashboard', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success) {
        setData(result);
      } else {
        throw new Error(result.message || 'Error al cargar datos');
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="flex items-center gap-2">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Cargando dashboard...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>
          Error al cargar el dashboard: {error}
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-2"
            onClick={fetchDashboardData}
          >
            Reintentar
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (!data) {
    return <div>No hay datos disponibles</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Panel de Administración</h1>
          <p className="text-muted-foreground">Vista general del sistema de fidelización</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar Datos
          </Button>
          <Button className="gap-2">
            <Gift className="h-4 w-4" />
            Crear Beneficio
          </Button>
        </div>
      </div>

      {/* Global Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventas Totales</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${data.metrics.totalSales.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {data.metrics.totalTransactions} transacciones
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clientes</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.metrics.totalCustomers}</div>
            <p className="text-xs text-muted-foreground">
              Clientes registrados
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Puntos Canjeados</CardTitle>
            <Award className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.metrics.totalPointsRedeemed.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Este mes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ticket Promedio</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${Math.round(data.metrics.averageTicket).toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Promedio por transacción
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts and Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ventas Mensuales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.chartData.map((month, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{month.month}</span>
                    <span className="font-medium">${month.sales.toLocaleString()}</span>
                  </div>
                  <Progress 
                    value={(month.sales / Math.max(...data.chartData.map(m => m.sales))) * 100} 
                    className="h-2"
                  />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Clientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.topCustomers.slice(0, 5).map((customer, index) => {
                const loyaltyInfo = getLoyaltyLevelInfo(customer.loyaltyLevel);
                return (
                  <div key={customer.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-bold">{index + 1}</span>
                      </div>
                      <div>
                        <p className="font-medium">{customer.user.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {customer.points} puntos • ${customer.totalSpent.toLocaleString()} gastado
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className={loyaltyInfo.color}>
                      {loyaltyInfo.name}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Branch Performance and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Rendimiento por Sucursal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.branchPerformance.map((branch) => (
                <div key={branch.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">{branch.name}</p>
                      <p className="text-sm text-muted-foreground">{branch.address}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${branch.totalSales.toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">{branch.customerCount} clientes</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Actividad Reciente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.recentPurchases.slice(0, 5).map((purchase) => (
                <div key={purchase.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">
                      Nueva venta - {purchase.branch.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(purchase.purchaseDate).toLocaleDateString()} • {purchase.customer.user.name}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${purchase.amount.toLocaleString()}</p>
                    <p className="text-sm text-primary">+{purchase.pointsEarned} puntos</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Loyalty Level Distribution */}
      {data.loyaltyStats.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Distribución de Niveles de Fidelidad</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              {data.loyaltyStats.map((stat) => {
                const loyaltyInfo = getLoyaltyLevelInfo(stat.level);
                return (
                  <div key={stat.level} className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold mb-2">{stat.count}</div>
                    <Badge variant="outline" className={loyaltyInfo.color}>
                      {loyaltyInfo.name}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Acciones Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Gift className="h-6 w-6" />
              <span className="text-sm">Gestionar Beneficios</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <MapPin className="h-6 w-6" />
              <span className="text-sm">Ver Sucursales</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Users className="h-6 w-6" />
              <span className="text-sm">Gestionar Clientes</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <BarChart3 className="h-6 w-6" />
              <span className="text-sm">Ver Reportes</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
