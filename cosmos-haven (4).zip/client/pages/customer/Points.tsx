import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Award, 
  TrendingUp, 
  Gift, 
  Calendar,
  ArrowRight,
  Star,
  Crown,
  Medal
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Customer } from '@shared/types';
import { getLoyaltyLevelInfo, getNextLoyaltyLevel } from '@/data/mockData';

export default function Points() {
  const { user } = useAuth();
  const customer = user as Customer;

  if (!customer || customer.role !== 'CUSTOMER') {
    return <div>Error: No se pudo cargar la información del cliente</div>;
  }

  const loyaltyInfo = getLoyaltyLevelInfo(customer.loyaltyLevel);
  const nextLevel = getNextLoyaltyLevel(customer.loyaltyLevel, customer.totalSpent);

  // Mock recent points history
  const pointsHistory = [
    { date: '2024-01-15', description: 'Compra en Sucursal Centro', points: 125, type: 'earned' },
    { date: '2024-01-13', description: 'Compra en Sucursal Centro', points: 90, type: 'earned' },
    { date: '2024-01-10', description: 'Canje: 10% de descuento', points: -500, type: 'redeemed' },
    { date: '2024-01-08', description: 'Compra en Sucursal Palermo', points: 200, type: 'earned' },
    { date: '2024-01-05', description: 'Bono de bienvenida', points: 100, type: 'bonus' },
  ];

  const totalEarned = pointsHistory.filter(h => h.type === 'earned' || h.type === 'bonus').reduce((sum, h) => sum + h.points, 0);
  const totalRedeemed = pointsHistory.filter(h => h.type === 'redeemed').reduce((sum, h) => sum + Math.abs(h.points), 0);

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'BRONZE':
      case 'bronze':
        return <Medal className="h-6 w-6" />;
      case 'SILVER':
      case 'silver':
        return <Star className="h-6 w-6" />;
      case 'GOLD':
      case 'gold':
        return <Crown className="h-6 w-6" />;
      default:
        return <Medal className="h-6 w-6" />;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'earned':
        return <TrendingUp className="h-4 w-4 text-success" />;
      case 'redeemed':
        return <Gift className="h-4 w-4 text-warning" />;
      case 'bonus':
        return <Award className="h-4 w-4 text-primary" />;
      default:
        return <TrendingUp className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mis Puntos</h1>
          <p className="text-muted-foreground">
            Gestiona tus puntos de fidelidad y revisa tu progreso
          </p>
        </div>
      </div>

      {/* Points Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Disponibles</p>
                <p className="text-3xl font-bold text-primary">{customer.points.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Listos para canjear</p>
              </div>
              <div className={`w-12 h-12 rounded-full ${loyaltyInfo.bgColor} flex items-center justify-center`}>
                {getLevelIcon(customer.loyaltyLevel)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Ganados</p>
                <p className="text-2xl font-bold text-success">{totalEarned.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Total histórico</p>
              </div>
              <TrendingUp className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Canjeados</p>
                <p className="text-2xl font-bold text-warning">{totalRedeemed.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">En beneficios</p>
              </div>
              <Gift className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Current Level & Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            Tu Nivel de Fidelidad
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-full ${loyaltyInfo.bgColor} flex items-center justify-center`}>
                  {getLevelIcon(customer.loyaltyLevel)}
                </div>
                <div>
                  <h3 className="text-2xl font-bold">{loyaltyInfo.name}</h3>
                  <p className="text-muted-foreground">Tu nivel actual</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Beneficios de tu nivel:</p>
                <ul className="space-y-1 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full" />
                    Acumulación de puntos estándar
                  </li>
                  {customer.loyaltyLevel !== 'bronze' && (
                    <li className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-primary rounded-full" />
                      Bonificaciones especiales
                    </li>
                  )}
                  {(customer.loyaltyLevel === 'GOLD' || customer.loyaltyLevel === 'gold') && (
                    <li className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-primary rounded-full" />
                      Beneficios exclusivos VIP
                    </li>
                  )}
                </ul>
              </div>
            </div>

            {nextLevel && nextLevel.remaining !== undefined && nextLevel.next && (
              <div className="space-y-4">
                <h4 className="font-semibold">Progreso al Siguiente Nivel</h4>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Nivel Actual: {loyaltyInfo.name}</span>
                    <span>Siguiente: {nextLevel.next}</span>
                  </div>
                  <Progress
                    value={typeof nextLevel.remaining === 'number' && customer.totalSpent
                      ? (customer.totalSpent / (customer.totalSpent + nextLevel.remaining)) * 100
                      : 0}
                    className="h-3"
                  />
                  <div className="text-center">
                    <p className="text-lg font-bold text-primary">
                      ${typeof nextLevel.remaining === 'number' ? nextLevel.remaining.toLocaleString() : '0'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Te faltan para alcanzar el nivel {nextLevel.next}
                    </p>
                  </div>
                </div>

                <Button className="w-full gap-2">
                  Ver Beneficios del Siguiente Nivel
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            )}

            {(customer.loyaltyLevel === 'GOLD' || customer.loyaltyLevel === 'gold') && (
              <div className="space-y-4">
                <div className="text-center p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg border border-yellow-200">
                  <Crown className="h-12 w-12 mx-auto text-yellow-600 mb-2" />
                  <h4 className="font-bold text-yellow-800">¡Felicitaciones!</h4>
                  <p className="text-sm text-yellow-700">
                    Has alcanzado nuestro nivel más alto. Disfruta de todos los beneficios VIP.
                  </p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Points History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Historial de Puntos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {pointsHistory.map((entry, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  {getTypeIcon(entry.type)}
                  <div>
                    <p className="font-medium">{entry.description}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(entry.date).toLocaleDateString('es-AR', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className={`font-bold ${
                    entry.points > 0 ? 'text-success' : 'text-warning'
                  }`}>
                    {entry.points > 0 ? '+' : ''}{entry.points.toLocaleString()} puntos
                  </p>
                  <Badge variant={
                    entry.type === 'earned' ? 'default' :
                    entry.type === 'redeemed' ? 'secondary' : 'outline'
                  } className="text-xs">
                    {entry.type === 'earned' ? 'Ganados' :
                     entry.type === 'redeemed' ? 'Canjeados' : 'Bonus'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 text-center">
            <Button variant="outline">Ver Historial Completo</Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Acciones Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Gift className="h-6 w-6" />
              <span className="text-sm">Ver Beneficios</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <TrendingUp className="h-6 w-6" />
              <span className="text-sm">Como Ganar Más Puntos</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Calendar className="h-6 w-6" />
              <span className="text-sm">Historial de Compras</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
