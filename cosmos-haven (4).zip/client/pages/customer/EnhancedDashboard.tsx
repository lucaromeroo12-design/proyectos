import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  Award, 
  CreditCard, 
  TrendingUp, 
  Gift, 
  Calendar,
  Star,
  Crown,
  Medal,
  ShoppingBag
} from 'lucide-react';
import { useCustomerApi } from '@/hooks/useApi';

interface DashboardData {
  customer: {
    id: string;
    name: string;
    email: string;
    dni: string;
    points: number;
    loyaltyLevel: 'BRONZE' | 'SILVER' | 'GOLD';
    totalSpent: number;
    registrationDate: string;
  };
  recentPurchases: any[];
  recentRedemptions: any[];
  chartData: Array<{
    month: string;
    points: number;
    spent: number;
    purchases: number;
  }>;
  nextLevel: {
    nextLevel: 'SILVER' | 'GOLD';
    amountNeeded: number;
    threshold: number;
  } | null;
  stats: {
    totalPurchases: number;
    totalPointsEarned: number;
    averageTicket: number;
  };
}

export default function EnhancedDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const customerApi = useCustomerApi();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setIsLoading(true);
    setError(null);

    const response = await customerApi.getDashboard();
    
    if (response.success && response.data) {
      setData(response.data);
    } else {
      setError(response.error || 'Error loading dashboard data');
    }
    
    setIsLoading(false);
  };

  const getLoyaltyInfo = (level: string) => {
    switch (level) {
      case 'BRONZE':
        return { 
          name: 'Bronce', 
          icon: Medal, 
          color: 'text-orange-600', 
          bgColor: 'bg-orange-100',
          chartColor: '#CD7F32'
        };
      case 'SILVER':
        return { 
          name: 'Plata', 
          icon: Star, 
          color: 'text-gray-600', 
          bgColor: 'bg-gray-100',
          chartColor: '#C0C0C0'
        };
      case 'GOLD':
        return { 
          name: 'Oro', 
          icon: Crown, 
          color: 'text-yellow-600', 
          bgColor: 'bg-yellow-100',
          chartColor: '#FFD700'
        };
      default:
        return { 
          name: 'Bronce', 
          icon: Medal, 
          color: 'text-orange-600', 
          bgColor: 'bg-orange-100',
          chartColor: '#CD7F32'
        };
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-96 mt-2" />
          </div>
          <Skeleton className="h-8 w-24" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-destructive mb-2">Error</h2>
          <p className="text-muted-foreground">{error || 'No se pudo cargar la información'}</p>
        </div>
      </div>
    );
  }

  const loyaltyInfo = getLoyaltyInfo(data.customer.loyaltyLevel);
  const LoyaltyIcon = loyaltyInfo.icon;

  // Prepare chart data
  const chartDataWithFormatted = data.chartData.map(item => ({
    ...item,
    monthFormatted: new Date(item.month + '-01').toLocaleDateString('es-ES', { 
      month: 'short',
      year: '2-digit'
    }),
  }));

  // Pie chart data for spending distribution
  const spendingData = data.recentPurchases
    .reduce((acc: any[], purchase) => {
      const branchName = purchase.branch?.name || 'Sucursal';
      const existing = acc.find(item => item.name === branchName);
      if (existing) {
        existing.value += purchase.amount;
      } else {
        acc.push({ name: branchName, value: purchase.amount });
      }
      return acc;
    }, [])
    .slice(0, 4);

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">¡Hola, {data.customer.name}!</h1>
          <p className="text-muted-foreground">Bienvenido a tu panel de fidelidad</p>
        </div>
        <Badge variant="secondary" className={`${loyaltyInfo.bgColor} ${loyaltyInfo.color} text-sm px-3 py-1 self-start sm:self-auto`}>
          <LoyaltyIcon className="h-4 w-4 mr-1" />
          Nivel {loyaltyInfo.name}
        </Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Disponibles</p>
                <p className="text-3xl font-bold text-primary">{data.customer.points.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Listos para canjear</p>
              </div>
              <Award className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Gasto Total</p>
                <p className="text-2xl font-bold">${data.customer.totalSpent.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Histórico</p>
              </div>
              <CreditCard className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Compras</p>
                <p className="text-2xl font-bold">{data.stats.totalPurchases}</p>
                <p className="text-sm text-muted-foreground">Realizadas</p>
              </div>
              <ShoppingBag className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Ticket Promedio</p>
                <p className="text-2xl font-bold">${data.stats.averageTicket.toFixed(0)}</p>
                <p className="text-sm text-muted-foreground">Por compra</p>
              </div>
              <TrendingUp className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress to Next Level */}
      {data.nextLevel && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Progreso al Siguiente Nivel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>Nivel Actual: {loyaltyInfo.name}</span>
                <span>Siguiente: {data.nextLevel.nextLevel === 'SILVER' ? 'Plata' : 'Oro'}</span>
              </div>
              <Progress 
                value={((data.nextLevel.threshold - data.nextLevel.amountNeeded) / data.nextLevel.threshold) * 100} 
                className="h-3"
              />
              <div className="text-center">
                <p className="text-lg font-bold text-primary">
                  ${data.nextLevel.amountNeeded.toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground">
                  Te faltan para alcanzar el nivel {data.nextLevel.nextLevel === 'SILVER' ? 'Plata' : 'Oro'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Points Evolution Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Evolución de Puntos</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartDataWithFormatted}>
                <defs>
                  <linearGradient id="colorPoints" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={loyaltyInfo.chartColor} stopOpacity={0.8}/>
                    <stop offset="95%" stopColor={loyaltyInfo.chartColor} stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="monthFormatted" />
                <YAxis />
                <CartesianGrid strokeDasharray="3 3" />
                <Tooltip 
                  formatter={(value, name) => [value, name === 'points' ? 'Puntos' : 'Gasto']}
                  labelFormatter={(label) => `Mes: ${label}`}
                />
                <Area 
                  type="monotone" 
                  dataKey="points" 
                  stroke={loyaltyInfo.chartColor}
                  fillOpacity={1} 
                  fill="url(#colorPoints)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Spending by Branch */}
        <Card>
          <CardHeader>
            <CardTitle>Gasto por Sucursal</CardTitle>
          </CardHeader>
          <CardContent>
            {spendingData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={spendingData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {spendingData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Gasto']} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-muted-foreground">
                No hay datos de gastos disponibles
              </div>
            )}
          </CardContent>
        </Card>

        {/* Monthly Purchases */}
        <Card>
          <CardHeader>
            <CardTitle>Compras Mensuales</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartDataWithFormatted}>
                <XAxis dataKey="monthFormatted" />
                <YAxis />
                <CartesianGrid strokeDasharray="3 3" />
                <Tooltip 
                  formatter={(value, name) => [value, name === 'purchases' ? 'Compras' : 'Gasto']}
                  labelFormatter={(label) => `Mes: ${label}`}
                />
                <Bar dataKey="purchases" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Actividad Reciente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-[300px] overflow-y-auto">
              {data.recentPurchases.map((purchase) => (
                <div key={purchase.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <ShoppingBag className="h-4 w-4 text-primary" />
                    <div>
                      <p className="font-medium">{purchase.branch?.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(purchase.purchaseDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${purchase.amount.toLocaleString()}</p>
                    <p className="text-sm text-primary">+{purchase.pointsEarned} puntos</p>
                  </div>
                </div>
              ))}
              
              {data.recentRedemptions.map((redemption) => (
                <div key={redemption.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Gift className="h-4 w-4 text-warning" />
                    <div>
                      <p className="font-medium">{redemption.benefit?.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(redemption.redeemedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-warning">-{redemption.pointsUsed} puntos</p>
                    <p className="text-sm text-muted-foreground">Canjeado</p>
                  </div>
                </div>
              ))}

              {data.recentPurchases.length === 0 && data.recentRedemptions.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No hay actividad reciente
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
