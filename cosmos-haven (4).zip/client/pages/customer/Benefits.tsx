import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Gift, 
  Award, 
  Percent, 
  Calendar,
  Star,
  Crown,
  CheckCircle,
  Lock
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Customer } from '@shared/types';
import { mockBenefits } from '@/data/mockData';

export default function Benefits() {
  const { user } = useAuth();
  const customer = user as Customer;
  const [selectedBenefit, setSelectedBenefit] = useState<any>(null);
  const [isRedeemDialogOpen, setIsRedeemDialogOpen] = useState(false);

  if (!customer || customer.role !== 'CUSTOMER') {
    return <div>Error: No se pudo cargar la información del cliente</div>;
  }

  const availableBenefits = mockBenefits.filter(benefit => {
    const levelOrder = { bronze: 1, silver: 2, gold: 3 };
    const customerLevel = levelOrder[customer.loyaltyLevel as keyof typeof levelOrder];
    const benefitLevel = levelOrder[benefit.minLoyaltyLevel as keyof typeof levelOrder || 'bronze'];
    return customerLevel >= benefitLevel && benefit.isActive;
  });

  const lockedBenefits = mockBenefits.filter(benefit => {
    const levelOrder = { bronze: 1, silver: 2, gold: 3 };
    const customerLevel = levelOrder[customer.loyaltyLevel as keyof typeof levelOrder];
    const benefitLevel = levelOrder[benefit.minLoyaltyLevel as keyof typeof levelOrder || 'bronze'];
    return customerLevel < benefitLevel && benefit.isActive;
  });

  const getBenefitIcon = (type: string) => {
    switch (type) {
      case 'discount':
        return <Percent className="h-6 w-6" />;
      case 'gift':
        return <Gift className="h-6 w-6" />;
      case 'coupon':
        return <Award className="h-6 w-6" />;
      default:
        return <Gift className="h-6 w-6" />;
    }
  };

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'silver':
        return <Star className="h-4 w-4" />;
      case 'gold':
        return <Crown className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const handleRedeem = (benefit: any) => {
    if (customer.points >= benefit.pointsCost) {
      // Mock redemption
      setSelectedBenefit(benefit);
      setIsRedeemDialogOpen(true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Beneficios Disponibles</h1>
          <p className="text-muted-foreground">
            Canjea tus puntos por increíbles beneficios y descuentos
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Puntos disponibles</p>
          <p className="text-2xl font-bold text-primary">{customer.points.toLocaleString()}</p>
        </div>
      </div>

      {/* Available Benefits */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <CheckCircle className="h-5 w-5 text-success" />
          Beneficios Disponibles ({availableBenefits.length})
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {availableBenefits.map((benefit) => (
            <Card key={benefit.id} className="relative overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      {getBenefitIcon(benefit.type)}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{benefit.title}</CardTitle>
                      {benefit.minLoyaltyLevel && benefit.minLoyaltyLevel !== 'bronze' && (
                        <Badge variant="outline" className="text-xs mt-1">
                          {getLevelIcon(benefit.minLoyaltyLevel)}
                          <span className="ml-1">{benefit.minLoyaltyLevel}</span>
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{benefit.description}</p>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-lg font-bold text-primary">{benefit.pointsCost}</p>
                    <p className="text-xs text-muted-foreground">puntos</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{benefit.value}</p>
                    <p className="text-xs text-muted-foreground">valor</p>
                  </div>
                </div>

                {benefit.validUntil && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    <span>Válido hasta: {new Date(benefit.validUntil).toLocaleDateString()}</span>
                  </div>
                )}

                <Button 
                  className="w-full"
                  disabled={customer.points < benefit.pointsCost}
                  onClick={() => handleRedeem(benefit)}
                >
                  {customer.points >= benefit.pointsCost ? 'Canjear' : 'Puntos insuficientes'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {availableBenefits.length === 0 && (
          <Card>
            <CardContent className="py-8 text-center">
              <Gift className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay beneficios disponibles</h3>
              <p className="text-muted-foreground">
                Sigue acumulando puntos para desbloquear beneficios increíbles
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Locked Benefits */}
      {lockedBenefits.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Lock className="h-5 w-5 text-muted-foreground" />
            Beneficios Bloqueados ({lockedBenefits.length})
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lockedBenefits.map((benefit) => (
              <Card key={benefit.id} className="relative overflow-hidden opacity-75">
                <div className="absolute inset-0 bg-muted/20 z-10 flex items-center justify-center">
                  <div className="text-center">
                    <Lock className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm font-medium">Nivel {benefit.minLoyaltyLevel} requerido</p>
                  </div>
                </div>
                
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                        {getBenefitIcon(benefit.type)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{benefit.title}</CardTitle>
                        <Badge variant="secondary" className="text-xs mt-1">
                          {getLevelIcon(benefit.minLoyaltyLevel)}
                          <span className="ml-1">{benefit.minLoyaltyLevel}</span>
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-lg font-bold text-muted-foreground">{benefit.pointsCost}</p>
                      <p className="text-xs text-muted-foreground">puntos</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-muted-foreground">{benefit.value}</p>
                      <p className="text-xs text-muted-foreground">valor</p>
                    </div>
                  </div>

                  <Button variant="secondary" disabled className="w-full">
                    Bloqueado
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Redemption Success Dialog */}
      <Dialog open={isRedeemDialogOpen} onOpenChange={setIsRedeemDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-success">
              <CheckCircle className="h-6 w-6" />
              ¡Canje Exitoso!
            </DialogTitle>
          </DialogHeader>
          
          {selectedBenefit && (
            <div className="space-y-4">
              <div className="text-center p-6 bg-success/10 rounded-lg">
                <div className="w-16 h-16 mx-auto bg-success/20 rounded-full flex items-center justify-center mb-4">
                  {getBenefitIcon(selectedBenefit.type)}
                </div>
                <h3 className="text-lg font-semibold mb-2">{selectedBenefit.title}</h3>
                <p className="text-muted-foreground mb-4">{selectedBenefit.description}</p>
                
                <div className="border-t pt-4">
                  <p className="text-sm text-muted-foreground mb-1">Código de canje:</p>
                  <p className="text-lg font-mono font-bold bg-background px-3 py-2 rounded border">
                    {Math.random().toString(36).substr(2, 8).toUpperCase()}
                  </p>
                </div>
              </div>
              
              <div className="text-center text-sm text-muted-foreground">
                <p>Presenta este código en cualquier sucursal para usar tu beneficio.</p>
                {selectedBenefit.validUntil && (
                  <p>Válido hasta: {new Date(selectedBenefit.validUntil).toLocaleDateString()}</p>
                )}
              </div>

              <Button onClick={() => setIsRedeemDialogOpen(false)} className="w-full">
                Entendido
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
