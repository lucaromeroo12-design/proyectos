import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Award, CreditCard, TrendingUp, Gift } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Customer } from '@shared/types';
import { getLoyaltyLevelInfo, getNextLoyaltyLevel } from '@/data/mockData';

export default function Dashboard() {
  const { user } = useAuth();
  const customer = user as Customer;

  if (!customer || customer.role !== 'CUSTOMER') {
    return <div>Error: No se pudo cargar la información del cliente</div>;
  }

  const loyaltyInfo = getLoyaltyLevelInfo(customer.loyaltyLevel);
  const nextLevel = getNextLoyaltyLevel(customer.loyaltyLevel, customer.totalSpent);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">¡Hola, {customer.name}!</h1>
          <p className="text-muted-foreground">Bienvenido a tu panel de fidelidad</p>
        </div>
        <Badge variant="secondary" className={`${loyaltyInfo.bgColor} ${loyaltyInfo.color} text-sm px-3 py-1 self-start sm:self-auto`}>
          Nivel {loyaltyInfo.name}
        </Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Puntos Disponibles</CardTitle>
            <Award className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{customer.points.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Listos para canjear
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Gasto Total</CardTitle>
            <CreditCard className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${customer.totalSpent.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Desde {new Date(customer.registrationDate).toLocaleDateString()}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Nivel de Fidelidad</CardTitle>
            <TrendingUp className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${loyaltyInfo.color}`}>
              {loyaltyInfo.name}
            </div>
            {nextLevel && nextLevel.remaining !== undefined && (
              <p className="text-xs text-muted-foreground">
                ${typeof nextLevel.remaining === 'number' ? nextLevel.remaining.toLocaleString() : '0'} para {nextLevel.next}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Beneficios Disponibles</CardTitle>
            <Gift className="h-4 w-4 text-accent-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground">
              Para tu nivel actual
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Progress to Next Level */}
      {nextLevel && nextLevel.remaining !== undefined && nextLevel.next && (
        <Card>
          <CardHeader>
            <CardTitle>Progreso al Siguiente Nivel</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Nivel Actual: {loyaltyInfo.name}</span>
                <span>Siguiente: {nextLevel.next}</span>
              </div>
              <Progress
                value={typeof nextLevel.remaining === 'number' && customer.totalSpent
                  ? (customer.totalSpent / (customer.totalSpent + nextLevel.remaining)) * 100
                  : 0}
                className="h-2"
              />
              <p className="text-sm text-muted-foreground">
                Te faltan ${typeof nextLevel.remaining === 'number' ? nextLevel.remaining.toLocaleString() : '0'} para alcanzar el nivel {nextLevel.next}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <button className="w-full p-3 text-left border rounded-lg hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-3">
                <Gift className="h-5 w-5 text-primary flex-shrink-0" />
                <div className="min-w-0">
                  <p className="font-medium">Ver Beneficios</p>
                  <p className="text-sm text-muted-foreground">Explora qué puedes canjear</p>
                </div>
              </div>
            </button>
            <button className="w-full p-3 text-left border rounded-lg hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-3">
                <CreditCard className="h-5 w-5 text-primary flex-shrink-0" />
                <div className="min-w-0">
                  <p className="font-medium">Historial de Compras</p>
                  <p className="text-sm text-muted-foreground">Revisa tus transacciones</p>
                </div>
              </div>
            </button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Últimas Compras</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-2 border rounded">
                <div>
                  <p className="font-medium">Sucursal Centro</p>
                  <p className="text-sm text-muted-foreground">15 Ene 2024</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">$2,500</p>
                  <p className="text-sm text-primary">+125 puntos</p>
                </div>
              </div>
              <div className="flex justify-between items-center p-2 border rounded">
                <div>
                  <p className="font-medium">Sucursal Centro</p>
                  <p className="text-sm text-muted-foreground">13 Ene 2024</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">$1,800</p>
                  <p className="text-sm text-primary">+90 puntos</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
