import React from 'react';
import { useAuth } from '@/context/AuthContext';
import AdminConfiguration from '@/pages/admin/Configuration';
import BranchConfiguration from '@/pages/branch/Configuration';
import CustomerConfiguration from '@/pages/customer/Configuration';

export default function Configuration() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-muted-foreground mb-2">Configuración</h1>
          <p className="text-muted-foreground">Debes iniciar sesión para acceder a la configuración.</p>
        </div>
      </div>
    );
  }

  // Route to appropriate configuration based on user role
  switch (user.role) {
    case 'ADMIN':
      return <AdminConfiguration />;
    case 'BRANCH':
      return <BranchConfiguration />;
    case 'CUSTOMER':
      return <CustomerConfiguration />;
    default:
      return (
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-muted-foreground mb-2">Error</h1>
            <p className="text-muted-foreground">Rol de usuario no válido.</p>
          </div>
        </div>
      );
  }
}
