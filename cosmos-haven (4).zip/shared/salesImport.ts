export interface SalesImportRequest {
  file: File;
}

export interface SalesImportResponse {
  success: boolean;
  processedCount: number;
  ignoredCount: number;
  errors: string[];
  summary: string;
  newCustomersCreated: number;
  totalPointsAdded: number;
}

export interface SalesPreviewRequest {
  file: File;
}

export interface SalesPreviewResponse {
  success: boolean;
  preview: Array<{
    row: number;
    nombre_cliente: string;
    dni_cliente: string;
    sucursal: string;
    fecha: string;
    monto: number;
    nro_factura: string;
    pointsToEarn: number;
    isValid: boolean;
    errors: string[];
  }>;
  totalRows: number;
  validRows: number;
  invalidRows: number;
}

export const REQUIRED_COLUMNS = [
  'nombre_cliente',
  'dni_cliente', 
  'sucursal',
  'fecha',
  'monto',
  'nro_factura'
] as const;

export function calculatePoints(amount: number): number {
  return Math.floor(amount / 1000);
}

export function validateSaleRow(row: any): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Check required fields
  for (const column of REQUIRED_COLUMNS) {
    if (!row[column] || row[column].toString().trim() === '') {
      errors.push(`Campo requerido: ${column}`);
    }
  }
  
  // Validate DNI (should be number or string)
  if (row.dni_cliente && isNaN(Number(row.dni_cliente))) {
    if (typeof row.dni_cliente !== 'string') {
      errors.push('DNI debe ser un número o texto');
    }
  }
  
  // Validate amount (should be positive number)
  if (row.monto) {
    const amount = Number(row.monto);
    if (isNaN(amount) || amount <= 0) {
      errors.push('Monto debe ser un número positivo');
    }
  }
  
  // Validate date format (YYYY-MM-DD)
  if (row.fecha) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(row.fecha)) {
      errors.push('Fecha debe estar en formato YYYY-MM-DD');
    } else {
      const date = new Date(row.fecha);
      if (isNaN(date.getTime())) {
        errors.push('Fecha inválida');
      }
    }
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}
