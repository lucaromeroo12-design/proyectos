import { PrismaClient, UserRole, LoyaltyLevel, BenefitType } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 12);
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@demo.com' },
    update: {},
    create: {
      email: 'admin@demo.com',
      password: adminPassword,
      name: 'Ana López',
      role: UserRole.ADMIN,
    },
  });

  console.log('👑 Admin user created:', adminUser.email);

  // Create branches
  const branches = await Promise.all([
    prisma.branch.upsert({
      where: { name: 'Sucursal Centro' },
      update: {},
      create: {
        name: 'Sucursal Centro',
        address: 'Av. Corrientes 1234, CABA',
        isActive: true,
      },
    }),
    prisma.branch.upsert({
      where: { name: 'Sucursal Palermo' },
      update: {},
      create: {
        name: 'Sucursal Palermo',
        address: 'Av. Santa Fe 5678, CABA',
        isActive: true,
      },
    }),
    prisma.branch.upsert({
      where: { name: 'Sucursal Belgrano' },
      update: {},
      create: {
        name: 'Sucursal Belgrano',
        address: 'Av. Cabildo 9876, CABA',
        isActive: true,
      },
    }),
  ]);

  console.log('🏢 Branches created:', branches.length);

  // Create branch manager
  const branchPassword = await bcrypt.hash('branch123', 12);
  const branchUser = await prisma.user.upsert({
    where: { email: 'sucursal@demo.com' },
    update: {},
    create: {
      email: 'sucursal@demo.com',
      password: branchPassword,
      name: 'Carlos Rodríguez',
      role: UserRole.BRANCH,
    },
  });

  // Update branch with manager
  await prisma.branch.update({
    where: { id: branches[0].id },
    data: { managerId: branchUser.id },
  });

  console.log('👨‍💼 Branch manager created:', branchUser.email);

  // Create customer users
  const customerPassword = await bcrypt.hash('customer123', 12);
  
  const customer1User = await prisma.user.upsert({
    where: { email: 'cliente@demo.com' },
    update: {},
    create: {
      email: 'cliente@demo.com',
      password: customerPassword,
      name: 'María González',
      role: UserRole.CUSTOMER,
    },
  });

  const customer2User = await prisma.user.create({
    data: {
      email: 'juan.perez@demo.com',
      password: customerPassword,
      name: 'Juan Pérez',
      role: UserRole.CUSTOMER,
    },
  });

  const customer3User = await prisma.user.create({
    data: {
      email: 'ana.martinez@demo.com',
      password: customerPassword,
      name: 'Ana Martínez',
      role: UserRole.CUSTOMER,
    },
  });

  // Create customer profiles
  const customer1 = await prisma.customer.upsert({
    where: { dni: '12345678' },
    update: {},
    create: {
      userId: customer1User.id,
      dni: '12345678',
      points: 1250,
      loyaltyLevel: LoyaltyLevel.SILVER,
      totalSpent: 15000,
    },
  });

  const customer2 = await prisma.customer.create({
    data: {
      userId: customer2User.id,
      dni: '87654321',
      points: 2500,
      loyaltyLevel: LoyaltyLevel.GOLD,
      totalSpent: 35000,
    },
  });

  const customer3 = await prisma.customer.create({
    data: {
      userId: customer3User.id,
      dni: '11223344',
      points: 500,
      loyaltyLevel: LoyaltyLevel.BRONZE,
      totalSpent: 5000,
    },
  });

  console.log('👥 Customers created:', 3);

  // Create benefits
  const benefits = await Promise.all([
    prisma.benefit.create({
      data: {
        title: '10% de descuento',
        description: 'Descuento del 10% en tu próxima compra',
        pointsCost: 500,
        type: BenefitType.DISCOUNT,
        value: '10%',
        isActive: true,
        minLoyaltyLevel: LoyaltyLevel.BRONZE,
      },
    }),
    prisma.benefit.create({
      data: {
        title: 'Café gratis',
        description: 'Un café gratis en cualquier sucursal',
        pointsCost: 200,
        type: BenefitType.GIFT,
        value: 'Café gratis',
        isActive: true,
        minLoyaltyLevel: LoyaltyLevel.BRONZE,
      },
    }),
    prisma.benefit.create({
      data: {
        title: '20% de descuento VIP',
        description: 'Descuento especial para miembros Gold',
        pointsCost: 1000,
        type: BenefitType.DISCOUNT,
        value: '20%',
        isActive: true,
        minLoyaltyLevel: LoyaltyLevel.GOLD,
      },
    }),
    prisma.benefit.create({
      data: {
        title: 'Regalo sorpresa',
        description: 'Un regalo especial seleccionado especialmente para ti',
        pointsCost: 750,
        type: BenefitType.GIFT,
        value: 'Regalo sorpresa',
        isActive: true,
        minLoyaltyLevel: LoyaltyLevel.SILVER,
      },
    }),
  ]);

  console.log('🎁 Benefits created:', benefits.length);

  // Create sample purchases
  const purchases = [];
  
  for (let i = 0; i < 10; i++) {
    const randomCustomer = [customer1, customer2, customer3][Math.floor(Math.random() * 3)];
    const randomBranch = branches[Math.floor(Math.random() * branches.length)];
    const amount = Math.floor(Math.random() * 5000) + 1000; // $1000-$6000
    const pointsEarned = Math.floor(amount / 1000);
    
    const purchase = await prisma.purchase.create({
      data: {
        customerId: randomCustomer.id,
        branchId: randomBranch.id,
        amount,
        pointsEarned,
        products: JSON.stringify([
          'Producto A',
          'Producto B',
          'Producto C',
        ].slice(0, Math.floor(Math.random() * 3) + 1)),
        invoiceNumber: `FAC-${Date.now()}-${i}`,
        purchaseDate: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000), // Random date in last 90 days
      },
    });
    
    purchases.push(purchase);
  }

  console.log('🛒 Sample purchases created:', purchases.length);

  // Create sample redemptions
  await prisma.redemption.create({
    data: {
      customerId: customer1.id,
      benefitId: benefits[0].id,
      pointsUsed: benefits[0].pointsCost,
      code: 'REDEEM001',
      status: 'USED',
      usedAt: new Date(),
    },
  });

  console.log('🎫 Sample redemption created');

  console.log('✅ Database seeded successfully!');
  console.log('\n📋 Demo Login Credentials:');
  console.log('👑 Admin: admin@demo.com / admin123');
  console.log('👨‍💼 Branch: sucursal@demo.com / branch123');
  console.log('👤 Customer: cliente@demo.com / customer123');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
