import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  Gift, 
  Plus, 
  Edit, 
  Trash2, 
  Award, 
  Percent, 
  Calendar,
  TrendingUp,
  Users
} from 'lucide-react';
import { mockBenefits } from '@/data/mockData';
import { Benefit, LoyaltyLevel } from '@shared/types';

export default function BenefitsManagement() {
  const [benefits, setBenefits] = useState<Benefit[]>(mockBenefits);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingBenefit, setEditingBenefit] = useState<Benefit | null>(null);
  const [newBenefit, setNewBenefit] = useState({
    title: '',
    description: '',
    pointsCost: 0,
    type: 'discount' as 'discount' | 'gift' | 'coupon',
    value: '',
    validUntil: '',
    minLoyaltyLevel: 'bronze' as LoyaltyLevel
  });

  const handleCreateBenefit = () => {
    const benefit: Benefit = {
      id: `benefit-${Date.now()}`,
      title: newBenefit.title,
      description: newBenefit.description,
      pointsCost: newBenefit.pointsCost,
      type: newBenefit.type,
      value: newBenefit.value,
      isActive: true,
      validUntil: newBenefit.validUntil || undefined,
      minLoyaltyLevel: newBenefit.minLoyaltyLevel
    };
    
    setBenefits([...benefits, benefit]);
    setNewBenefit({
      title: '',
      description: '',
      pointsCost: 0,
      type: 'discount',
      value: '',
      validUntil: '',
      minLoyaltyLevel: 'bronze'
    });
    setIsCreateDialogOpen(false);
  };

  const handleToggleActive = (benefitId: string) => {
    setBenefits(benefits.map(benefit => 
      benefit.id === benefitId 
        ? { ...benefit, isActive: !benefit.isActive }
        : benefit
    ));
  };

  const handleDeleteBenefit = (benefitId: string) => {
    setBenefits(benefits.filter(benefit => benefit.id !== benefitId));
  };

  const activeBenefits = benefits.filter(b => b.isActive).length;
  const totalRedemptions = 248; // Mock data
  const pointsRedeemed = 12500; // Mock data

  const getBenefitTypeIcon = (type: string) => {
    switch (type) {
      case 'discount':
        return <Percent className="h-4 w-4" />;
      case 'gift':
        return <Gift className="h-4 w-4" />;
      case 'coupon':
        return <Award className="h-4 w-4" />;
      default:
        return <Gift className="h-4 w-4" />;
    }
  };

  const getLoyaltyLevelColor = (level: string) => {
    switch (level) {
      case 'bronze':
        return 'bg-orange-100 text-orange-800';
      case 'silver':
        return 'bg-gray-100 text-gray-800';
      case 'gold':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Beneficios</h1>
          <p className="text-muted-foreground">
            Administra cupones, descuentos y regalos del programa de fidelización
          </p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nuevo Beneficio
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Crear Nuevo Beneficio</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Título del Beneficio</Label>
                  <Input
                    id="title"
                    value={newBenefit.title}
                    onChange={(e) => setNewBenefit({...newBenefit, title: e.target.value})}
                    placeholder="Ej: 10% de descuento"
                  />
                </div>
                <div>
                  <Label htmlFor="type">Tipo de Beneficio</Label>
                  <Select 
                    value={newBenefit.type} 
                    onValueChange={(value: 'discount' | 'gift' | 'coupon') => 
                      setNewBenefit({...newBenefit, type: value})
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="discount">Descuento</SelectItem>
                      <SelectItem value="gift">Regalo</SelectItem>
                      <SelectItem value="coupon">Cupón</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={newBenefit.description}
                  onChange={(e) => setNewBenefit({...newBenefit, description: e.target.value})}
                  placeholder="Describe los detalles del beneficio..."
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="points">Costo en Puntos</Label>
                  <Input
                    id="points"
                    type="number"
                    value={newBenefit.pointsCost}
                    onChange={(e) => setNewBenefit({...newBenefit, pointsCost: parseInt(e.target.value) || 0})}
                    placeholder="500"
                  />
                </div>
                <div>
                  <Label htmlFor="value">Valor</Label>
                  <Input
                    id="value"
                    value={newBenefit.value}
                    onChange={(e) => setNewBenefit({...newBenefit, value: e.target.value})}
                    placeholder="10% o Café gratis"
                  />
                </div>
                <div>
                  <Label htmlFor="validUntil">Válido hasta (opcional)</Label>
                  <Input
                    id="validUntil"
                    type="date"
                    value={newBenefit.validUntil}
                    onChange={(e) => setNewBenefit({...newBenefit, validUntil: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="loyalty">Nivel Mínimo de Fidelidad</Label>
                <Select 
                  value={newBenefit.minLoyaltyLevel} 
                  onValueChange={(value: LoyaltyLevel) => 
                    setNewBenefit({...newBenefit, minLoyaltyLevel: value})
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bronze">Bronce</SelectItem>
                    <SelectItem value="silver">Plata</SelectItem>
                    <SelectItem value="gold">Oro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleCreateBenefit} disabled={!newBenefit.title || !newBenefit.description}>
                  Crear Beneficio
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Beneficios</p>
                <p className="text-2xl font-bold">{benefits.length}</p>
              </div>
              <Gift className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Beneficios Activos</p>
                <p className="text-2xl font-bold text-success">{activeBenefits}</p>
              </div>
              <Award className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Canjes Totales</p>
                <p className="text-2xl font-bold">{totalRedemptions}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Canjeados</p>
                <p className="text-2xl font-bold">{pointsRedeemed.toLocaleString()}</p>
              </div>
              <Users className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Benefits List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Beneficios</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {benefits.map((benefit) => (
              <div key={benefit.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                      benefit.isActive ? 'bg-primary/10' : 'bg-muted'
                    }`}>
                      {getBenefitTypeIcon(benefit.type)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold">{benefit.title}</h3>
                        <Badge variant={benefit.isActive ? "default" : "secondary"}>
                          {benefit.isActive ? 'Activo' : 'Inactivo'}
                        </Badge>
                        <Badge className={getLoyaltyLevelColor(benefit.minLoyaltyLevel || 'bronze')}>
                          {benefit.minLoyaltyLevel || 'bronze'}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-sm mb-1">{benefit.description}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Valor: {benefit.value}</span>
                        {benefit.validUntil && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Válido hasta: {new Date(benefit.validUntil).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-lg font-bold text-primary">{benefit.pointsCost}</p>
                      <p className="text-xs text-muted-foreground">puntos</p>
                    </div>
                    
                    <div className="text-right mr-4">
                      <p className="text-sm font-medium">{Math.floor(Math.random() * 50) + 10}</p>
                      <p className="text-xs text-muted-foreground">canjes</p>
                    </div>
                    
                    <div className="flex items-center gap-1">
                      <Label htmlFor={`active-${benefit.id}`} className="text-sm">
                        Activo
                      </Label>
                      <Switch
                        id={`active-${benefit.id}`}
                        checked={benefit.isActive}
                        onCheckedChange={() => handleToggleActive(benefit.id)}
                      />
                    </div>
                    
                    <Button variant="ghost" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleDeleteBenefit(benefit.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {benefits.length === 0 && (
            <div className="text-center py-8">
              <Gift className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay beneficios</h3>
              <p className="text-muted-foreground mb-4">
                Comienza creando tu primer beneficio para los clientes
              </p>
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Crear Beneficio
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Popular Benefits */}
      <Card>
        <CardHeader>
          <CardTitle>Beneficios Más Populares</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {benefits
              .filter(b => b.isActive)
              .sort(() => Math.random() - 0.5)
              .slice(0, 5)
              .map((benefit, index) => {
                const redemptions = Math.floor(Math.random() * 100) + 20;
                
                return (
                  <div key={benefit.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-bold">{index + 1}</span>
                      </div>
                      <div>
                        <p className="font-medium">{benefit.title}</p>
                        <p className="text-sm text-muted-foreground">{benefit.pointsCost} puntos</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="font-medium">{redemptions}</p>
                        <p className="text-xs text-muted-foreground">Canjes</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{redemptions * benefit.pointsCost}</p>
                        <p className="text-xs text-muted-foreground">Puntos gastados</p>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
