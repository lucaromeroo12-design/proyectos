import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  Download, 
  Calendar, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  Users,
  Award,
  Gift,
  Target,
  FileText,
  Filter
} from 'lucide-react';

interface ChartData {
  name: string;
  value: number;
  change?: number;
}

export default function Reports() {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedBranch, setSelectedBranch] = useState('all');

  // Mock data for charts
  const salesData: ChartData[] = [
    { name: 'Ene', value: 95000, change: 12 },
    { name: 'Feb', value: 108000, change: 8 },
    { name: 'Mar', value: 125000, change: 15 },
    { name: 'Abr', value: 118000, change: -5 },
    { name: 'May', value: 142000, change: 20 },
    { name: 'Jun', value: 158000, change: 11 },
  ];

  const customerGrowth: ChartData[] = [
    { name: 'Ene', value: 120 },
    { name: 'Feb', value: 135 },
    { name: 'Mar', value: 150 },
    { name: 'Abr', value: 148 },
    { name: 'May', value: 165 },
    { name: 'Jun', value: 180 },
  ];

  const loyaltyDistribution = [
    { level: 'Bronce', count: 85, percentage: 47.2 },
    { level: 'Plata', count: 65, percentage: 36.1 },
    { level: 'Oro', count: 30, percentage: 16.7 },
  ];

  const topProducts = [
    { name: 'Producto Premium A', sales: 156, revenue: 78000 },
    { name: 'Combo Familiar', sales: 134, revenue: 67000 },
    { name: 'Producto Estrella', sales: 98, revenue: 49000 },
    { name: 'Oferta Especial', sales: 87, revenue: 43500 },
    { name: 'Pack Promocional', sales: 76, revenue: 38000 },
  ];

  const branchPerformance = [
    { name: 'Sucursal Centro', sales: 68000, customers: 45, growth: 12 },
    { name: 'Sucursal Palermo', sales: 52000, customers: 38, growth: 8 },
    { name: 'Sucursal Belgrano', sales: 38000, customers: 29, growth: -2 },
  ];

  const pointsData = {
    earned: 15420,
    redeemed: 8350,
    pending: 7070,
    redemptionRate: 54.2
  };

  const exportReport = (type: string) => {
    // Mock export functionality
    console.log(`Exporting ${type} report...`);
    // In a real app, this would generate and download the actual report
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Reportes y Métricas</h1>
          <p className="text-muted-foreground">
            Análisis detallado del rendimiento del programa de fidelización
          </p>
        </div>
        
        <div className="flex gap-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <SelectValue />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Esta Semana</SelectItem>
              <SelectItem value="month">Este Mes</SelectItem>
              <SelectItem value="quarter">Este Trimestre</SelectItem>
              <SelectItem value="year">Este Año</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={selectedBranch} onValueChange={setSelectedBranch}>
            <SelectTrigger className="w-48">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <SelectValue />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las Sucursales</SelectItem>
              <SelectItem value="centro">Sucursal Centro</SelectItem>
              <SelectItem value="palermo">Sucursal Palermo</SelectItem>
              <SelectItem value="belgrano">Sucursal Belgrano</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar Todo
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">General</TabsTrigger>
          <TabsTrigger value="sales">Ventas</TabsTrigger>
          <TabsTrigger value="customers">Clientes</TabsTrigger>
          <TabsTrigger value="loyalty">Fidelización</TabsTrigger>
          <TabsTrigger value="branches">Sucursales</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Ventas Totales</p>
                    <p className="text-2xl font-bold">$158,000</p>
                    <p className="text-sm text-success flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      +11% vs período anterior
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Nuevos Clientes</p>
                    <p className="text-2xl font-bold">24</p>
                    <p className="text-sm text-success flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      +15% vs período anterior
                    </p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Puntos Canjeados</p>
                    <p className="text-2xl font-bold">8,350</p>
                    <p className="text-sm text-warning flex items-center gap-1">
                      <TrendingDown className="h-3 w-3" />
                      -3% vs período anterior
                    </p>
                  </div>
                  <Award className="h-8 w-8 text-warning" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Tasa de Retención</p>
                    <p className="text-2xl font-bold">78.5%</p>
                    <p className="text-sm text-success flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      +2.3% vs período anterior
                    </p>
                  </div>
                  <Target className="h-8 w-8 text-success" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Evolución de Ventas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {salesData.map((data, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm font-medium">{data.name}</span>
                      <div className="flex items-center gap-4">
                        <div className="w-32 bg-muted rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${(data.value / 160000) * 100}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium w-20 text-right">
                          ${(data.value / 1000).toFixed(0)}k
                        </span>
                        {data.change && (
                          <Badge variant={data.change > 0 ? "default" : "destructive"} className="text-xs">
                            {data.change > 0 ? '+' : ''}{data.change}%
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Crecimiento de Clientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {customerGrowth.map((data, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm font-medium">{data.name}</span>
                      <div className="flex items-center gap-4">
                        <div className="w-32 bg-muted rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${(data.value / 200) * 100}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium w-16 text-right">
                          {data.value}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Export Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Exportar Reportes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button variant="outline" onClick={() => exportReport('sales')} className="h-20 flex-col gap-2">
                  <BarChart3 className="h-6 w-6" />
                  <span className="text-sm">Reporte de Ventas</span>
                </Button>
                <Button variant="outline" onClick={() => exportReport('customers')} className="h-20 flex-col gap-2">
                  <Users className="h-6 w-6" />
                  <span className="text-sm">Base de Clientes</span>
                </Button>
                <Button variant="outline" onClick={() => exportReport('loyalty')} className="h-20 flex-col gap-2">
                  <Award className="h-6 w-6" />
                  <span className="text-sm">Programa Fidelidad</span>
                </Button>
                <Button variant="outline" onClick={() => exportReport('financial')} className="h-20 flex-col gap-2">
                  <FileText className="h-6 w-6" />
                  <span className="text-sm">Reporte Financiero</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sales" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Productos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topProducts.map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="text-sm font-bold">{index + 1}</span>
                        </div>
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">{product.sales} unidades</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${product.revenue.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">ingresos</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Métricas de Ventas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold">$2,847</p>
                    <p className="text-sm text-muted-foreground">Ticket Promedio</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold">156</p>
                    <p className="text-sm text-muted-foreground">Transacciones</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold">2.3</p>
                    <p className="text-sm text-muted-foreground">Items por Venta</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold">89%</p>
                    <p className="text-sm text-muted-foreground">Satisfacción</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="customers" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribución por Niveles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {loyaltyDistribution.map((level, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">{level.level}</span>
                        <span className="text-sm text-muted-foreground">
                          {level.count} clientes ({level.percentage}%)
                        </span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            level.level === 'Bronce' ? 'bg-orange-500' :
                            level.level === 'Plata' ? 'bg-gray-500' : 'bg-yellow-500'
                          }`}
                          style={{ width: `${level.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Análisis de Retención</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold text-success">78.5%</p>
                    <p className="text-sm text-muted-foreground">Tasa de Retención</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold">32 días</p>
                    <p className="text-sm text-muted-foreground">Tiempo entre Compras</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold">4.2</p>
                    <p className="text-sm text-muted-foreground">Compras por Cliente</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="loyalty" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Actividad de Puntos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold text-primary">{pointsData.earned.toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">Puntos Ganados</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <p className="text-2xl font-bold text-warning">{pointsData.redeemed.toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">Puntos Canjeados</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Tasa de Canje</span>
                    <span>{pointsData.redemptionRate}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full" 
                      style={{ width: `${pointsData.redemptionRate}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Beneficios Más Populares</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">10% de descuento</span>
                    <Badge>45 canjes</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Café gratis</span>
                    <Badge>38 canjes</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">20% descuento VIP</span>
                    <Badge>22 canjes</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Regalo sorpresa</span>
                    <Badge>18 canjes</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="branches" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Rendimiento por Sucursal</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {branchPerformance.map((branch, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-semibold">{branch.name}</h3>
                      <p className="text-sm text-muted-foreground">{branch.customers} clientes activos</p>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="font-bold">${branch.sales.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">Ventas</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold ${branch.growth > 0 ? 'text-success' : 'text-destructive'}`}>
                          {branch.growth > 0 ? '+' : ''}{branch.growth}%
                        </p>
                        <p className="text-sm text-muted-foreground">Crecimiento</p>
                      </div>
                      <div className="w-24">
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full" 
                            style={{ width: `${(branch.sales / 70000) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
