import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { SalesImportUpload } from '@/components/admin/SalesImportUpload';
import { SalesImportPreview } from '@/components/admin/SalesImportPreview';
import { useSalesImport } from '@/hooks/useSalesImport';
import { SalesPreviewResponse, SalesImportResponse } from '@shared/salesImport';
import { CheckCircle, ArrowLeft, Download, FileSpreadsheet } from 'lucide-react';

type ImportStep = 'upload' | 'preview' | 'success';

export default function SalesImport() {
  const [currentStep, setCurrentStep] = useState<ImportStep>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewData, setPreviewData] = useState<SalesPreviewResponse | null>(null);
  const [importResult, setImportResult] = useState<SalesImportResponse | null>(null);
  
  const { previewSales, processSales, isLoading, error } = useSalesImport();

  const handleFileSelect = async (file: File) => {
    setSelectedFile(file);
    
    const preview = await previewSales(file);
    if (preview && preview.success) {
      setPreviewData(preview);
      setCurrentStep('preview');
    }
  };

  const handleConfirmImport = async () => {
    if (!selectedFile) return;
    
    const result = await processSales(selectedFile);
    if (result && result.success) {
      setImportResult(result);
      setCurrentStep('success');
    }
  };

  const handleStartOver = () => {
    setCurrentStep('upload');
    setSelectedFile(null);
    setPreviewData(null);
    setImportResult(null);
  };

  const downloadTemplate = () => {
    // Create a sample CSV template
    const csvContent = `nombre_cliente,dni_cliente,sucursal,fecha,monto,nro_factura
Juan Pérez,12345678,Sucursal Centro,2024-01-15,2500,FAC001
María González,87654321,Sucursal Palermo,2024-01-15,1800,FAC002
Carlos Rodríguez,11223344,Sucursal Belgrano,2024-01-16,3200,FAC003`;
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'plantilla_ventas.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Importar Ventas desde Excel/CSV</h1>
          <p className="text-muted-foreground">
            Carga masiva de ventas para actualizar puntos de fidelización
          </p>
        </div>
        
        {currentStep !== 'upload' && (
          <Button variant="outline" onClick={handleStartOver} className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Volver al Inicio
          </Button>
        )}
      </div>

      {/* Step Indicators */}
      <div className="flex items-center gap-4">
        <div className={`flex items-center gap-2 ${
          currentStep === 'upload' ? 'text-primary' : 'text-muted-foreground'
        }`}>
          <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
            currentStep !== 'upload' ? 'bg-primary border-primary text-primary-foreground' : 'border-current'
          }`}>
            {currentStep !== 'upload' ? <CheckCircle className="h-4 w-4" /> : '1'}
          </div>
          <span className="font-medium">Subir Archivo</span>
        </div>
        
        <div className="h-px bg-border flex-1" />
        
        <div className={`flex items-center gap-2 ${
          currentStep === 'preview' ? 'text-primary' : 'text-muted-foreground'
        }`}>
          <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
            currentStep === 'success' ? 'bg-primary border-primary text-primary-foreground' : 'border-current'
          }`}>
            {currentStep === 'success' ? <CheckCircle className="h-4 w-4" /> : '2'}
          </div>
          <span className="font-medium">Vista Previa</span>
        </div>
        
        <div className="h-px bg-border flex-1" />
        
        <div className={`flex items-center gap-2 ${
          currentStep === 'success' ? 'text-primary' : 'text-muted-foreground'
        }`}>
          <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
            currentStep === 'success' ? 'bg-primary border-primary text-primary-foreground' : 'border-current'
          }`}>
            {currentStep === 'success' ? <CheckCircle className="h-4 w-4" /> : '3'}
          </div>
          <span className="font-medium">Completado</span>
        </div>
      </div>

      {/* Content based on current step */}
      {currentStep === 'upload' && (
        <div className="space-y-6">
          <SalesImportUpload 
            onFileSelect={handleFileSelect}
            isLoading={isLoading}
            error={error}
          />
          
          {/* Template Download */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5" />
                ¿Necesitas una plantilla?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Descarga una plantilla CSV de ejemplo con el formato correcto y datos de muestra.
              </p>
              <Button variant="outline" onClick={downloadTemplate} className="gap-2">
                <Download className="h-4 w-4" />
                Descargar Plantilla CSV
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {currentStep === 'preview' && previewData && (
        <SalesImportPreview
          previewData={previewData}
          onConfirm={handleConfirmImport}
          onCancel={handleStartOver}
          isProcessing={isLoading}
        />
      )}

      {currentStep === 'success' && importResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-success">
              <CheckCircle className="h-6 w-6" />
              Importación Completada
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription className="text-lg">
                {importResult.summary}
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-success/10 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-success">
                  {importResult.processedCount}
                </div>
                <div className="text-sm text-muted-foreground">Ventas Procesadas</div>
              </div>
              
              <div className="bg-muted rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-muted-foreground">
                  {importResult.ignoredCount}
                </div>
                <div className="text-sm text-muted-foreground">Filas Ignoradas</div>
              </div>
              
              <div className="bg-primary/10 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-primary">
                  {importResult.totalPointsAdded || 0}
                </div>
                <div className="text-sm text-muted-foreground">Puntos Añadidos</div>
              </div>
            </div>

            {importResult.errors.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Errores encontrados:</h4>
                <div className="bg-destructive/10 rounded-lg p-3 max-h-32 overflow-y-auto">
                  {importResult.errors.map((error, index) => (
                    <div key={index} className="text-sm text-destructive">
                      {error}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <Button onClick={handleStartOver} className="gap-2">
                <FileSpreadsheet className="h-4 w-4" />
                Importar Otro Archivo
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/dashboard'}>
                Ir al Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
