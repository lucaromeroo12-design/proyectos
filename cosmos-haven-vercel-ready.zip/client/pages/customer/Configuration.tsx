import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  User,
  Bell,
  Shield,
  Eye,
  Save,
  Lock,
  Mail,
  Phone,
  MapPin,
  CreditCard,
  Gift,
  Star,
  Trash2,
  Download,
  Settings
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Customer } from '@shared/types';
import PasswordChange from '@/components/settings/PasswordChange';

export default function CustomerConfiguration() {
  const { user } = useAuth();
  const customer = user as Customer;
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  
  const [profileSettings, setProfileSettings] = useState({
    name: customer?.name || '',
    email: customer?.email || '',
    phone: '+54 11 1234-5678',
    birthDate: '1990-01-01',
    address: 'Av. Corrientes 1234, CABA',
    preferredBranch: 'Sucursal Centro',
  });

  const [notificationSettings, setNotificationSettings] = useState({
    purchaseConfirmations: true,
    pointsUpdates: true,
    levelUpgrades: true,
    benefitExpiration: true,
    promotionalOffers: false,
    newsletterSubscription: true,
    birthdayOffers: true,
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
  });

  const [privacySettings, setPrivacySettings] = useState({
    shareDataForImprovement: true,
    allowPersonalizedOffers: true,
    showInLeaderboards: false,
    allowContactFromBranches: true,
    dataRetentionConsent: true,
  });

  const [preferencesSettings, setPreferencesSettings] = useState({
    language: 'es',
    currency: 'ARS',
    theme: 'system',
    dateFormat: 'DD/MM/YYYY',
    autoRedeem: false,
    favoriteCategories: ['Electrónicos', 'Ropa'],
  });

  const handleSave = async (section: string) => {
    setSaveStatus('saving');
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (error) {
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const getSaveButtonText = () => {
    switch (saveStatus) {
      case 'saving': return 'Guardando...';
      case 'saved': return 'Guardado ✓';
      case 'error': return 'Error al guardar';
      default: return 'Guardar cambios';
    }
  };

  const getLoyaltyInfo = () => {
    if (!customer) return { name: 'Bronce', color: 'text-amber-600 bg-amber-50' };
    
    switch (customer.loyaltyLevel) {
      case 'SILVER':
        return { name: 'Plata', color: 'text-gray-600 bg-gray-50' };
      case 'GOLD':
        return { name: 'Oro', color: 'text-yellow-600 bg-yellow-50' };
      default:
        return { name: 'Bronce', color: 'text-amber-600 bg-amber-50' };
    }
  };

  const loyaltyInfo = getLoyaltyInfo();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mi Configuración</h1>
          <p className="text-muted-foreground">Personaliza tu perfil y preferencias</p>
        </div>
      </div>

      {/* Profile Overview Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="text-lg">
                {profileSettings.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-xl font-semibold">{profileSettings.name}</h2>
              <p className="text-muted-foreground">{profileSettings.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline" className={loyaltyInfo.color}>
                  <Star className="h-3 w-3 mr-1" />
                  {loyaltyInfo.name}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {customer?.points || 0} puntos acumulados
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile" className="gap-2">
            <User className="h-4 w-4" />
            Perfil
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2">
            <Bell className="h-4 w-4" />
            Notificaciones
          </TabsTrigger>
          <TabsTrigger value="privacy" className="gap-2">
            <Shield className="h-4 w-4" />
            Privacidad
          </TabsTrigger>
          <TabsTrigger value="preferences" className="gap-2">
            <Settings className="h-4 w-4" />
            Preferencias
          </TabsTrigger>
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Información Personal</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-6">
                  <Avatar className="h-20 w-20">
                    <AvatarFallback className="text-lg">
                      {profileSettings.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="space-y-2">
                    <Button variant="outline" size="sm">Cambiar Foto</Button>
                    <p className="text-sm text-muted-foreground">JPG, PNG hasta 5MB</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre Completo</Label>
                    <Input
                      id="name"
                      value={profileSettings.name}
                      onChange={(e) => setProfileSettings(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profileSettings.email}
                      onChange={(e) => setProfileSettings(prev => ({ ...prev, email: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      value={profileSettings.phone}
                      onChange={(e) => setProfileSettings(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="birthDate">Fecha de Nacimiento</Label>
                    <Input
                      id="birthDate"
                      type="date"
                      value={profileSettings.birthDate}
                      onChange={(e) => setProfileSettings(prev => ({ ...prev, birthDate: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Dirección</Label>
                  <Input
                    id="address"
                    value={profileSettings.address}
                    onChange={(e) => setProfileSettings(prev => ({ ...prev, address: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="preferredBranch">Sucursal Preferida</Label>
                  <Select value={profileSettings.preferredBranch} onValueChange={(value) => setProfileSettings(prev => ({ ...prev, preferredBranch: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Sucursal Centro">Sucursal Centro</SelectItem>
                      <SelectItem value="Sucursal Palermo">Sucursal Palermo</SelectItem>
                      <SelectItem value="Sucursal Belgrano">Sucursal Belgrano</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={() => handleSave('profile')} disabled={saveStatus === 'saving'}>
                  <Save className="h-4 w-4 mr-2" />
                  {getSaveButtonText()}
                </Button>
              </CardContent>
            </Card>

            <PasswordChange onSuccess={() => console.log('Password changed successfully')} />
          </div>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Notificaciones</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Notificaciones de Actividad</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Confirmaciones de Compra</Label>
                      <p className="text-sm text-muted-foreground">Notificar cuando realices una compra</p>
                    </div>
                    <Switch
                      checked={notificationSettings.purchaseConfirmations}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, purchaseConfirmations: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Actualizaciones de Puntos</Label>
                      <p className="text-sm text-muted-foreground">Cuando ganes o canjees puntos</p>
                    </div>
                    <Switch
                      checked={notificationSettings.pointsUpdates}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, pointsUpdates: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Subidas de Nivel</Label>
                      <p className="text-sm text-muted-foreground">Cuando alcances un nuevo nivel de fidelidad</p>
                    </div>
                    <Switch
                      checked={notificationSettings.levelUpgrades}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, levelUpgrades: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Expiración de Beneficios</Label>
                      <p className="text-sm text-muted-foreground">Recordatorios de beneficios próximos a expirar</p>
                    </div>
                    <Switch
                      checked={notificationSettings.benefitExpiration}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, benefitExpiration: checked }))}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Ofertas y Promociones</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Ofertas Promocionales</Label>
                      <p className="text-sm text-muted-foreground">Recibir ofertas especiales y descuentos</p>
                    </div>
                    <Switch
                      checked={notificationSettings.promotionalOffers}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, promotionalOffers: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Newsletter</Label>
                      <p className="text-sm text-muted-foreground">Boletín informativo mensual</p>
                    </div>
                    <Switch
                      checked={notificationSettings.newsletterSubscription}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, newsletterSubscription: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Ofertas de Cumpleaños</Label>
                      <p className="text-sm text-muted-foreground">Descuentos especiales en tu cumpleaños</p>
                    </div>
                    <Switch
                      checked={notificationSettings.birthdayOffers}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, birthdayOffers: checked }))}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Canales de Notificación</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1 flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      <div>
                        <Label>Email</Label>
                        <p className="text-sm text-muted-foreground">Notificaciones por correo electrónico</p>
                      </div>
                    </div>
                    <Switch
                      checked={notificationSettings.emailNotifications}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, emailNotifications: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1 flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <div>
                        <Label>SMS</Label>
                        <p className="text-sm text-muted-foreground">Mensajes de texto</p>
                      </div>
                    </div>
                    <Switch
                      checked={notificationSettings.smsNotifications}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, smsNotifications: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1 flex items-center gap-2">
                      <Bell className="h-4 w-4" />
                      <div>
                        <Label>Push</Label>
                        <p className="text-sm text-muted-foreground">Notificaciones en la aplicación</p>
                      </div>
                    </div>
                    <Switch
                      checked={notificationSettings.pushNotifications}
                      onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, pushNotifications: checked }))}
                    />
                  </div>
                </div>
              </div>

              <Button onClick={() => handleSave('notifications')} disabled={saveStatus === 'saving'}>
                <Save className="h-4 w-4 mr-2" />
                {getSaveButtonText()}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacy */}
        <TabsContent value="privacy">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Privacidad</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  Tu privacidad es importante para nosotros. Estas configuraciones te dan control sobre cómo se usan tus datos.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Uso de Datos</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Compartir Datos para Mejoras</Label>
                      <p className="text-sm text-muted-foreground">Ayúdanos a mejorar la aplicación con datos anónimos</p>
                    </div>
                    <Switch
                      checked={privacySettings.shareDataForImprovement}
                      onCheckedChange={(checked) => setPrivacySettings(prev => ({ ...prev, shareDataForImprovement: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Ofertas Personalizadas</Label>
                      <p className="text-sm text-muted-foreground">Permitir ofertas basadas en tu historial de compras</p>
                    </div>
                    <Switch
                      checked={privacySettings.allowPersonalizedOffers}
                      onCheckedChange={(checked) => setPrivacySettings(prev => ({ ...prev, allowPersonalizedOffers: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Contacto desde Sucursales</Label>
                      <p className="text-sm text-muted-foreground">Permitir que las sucursales te contacten</p>
                    </div>
                    <Switch
                      checked={privacySettings.allowContactFromBranches}
                      onCheckedChange={(checked) => setPrivacySettings(prev => ({ ...prev, allowContactFromBranches: checked }))}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Visibilidad</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Mostrar en Rankings</Label>
                      <p className="text-sm text-muted-foreground">Aparecer en tablas de clasificación públicas</p>
                    </div>
                    <Switch
                      checked={privacySettings.showInLeaderboards}
                      onCheckedChange={(checked) => setPrivacySettings(prev => ({ ...prev, showInLeaderboards: checked }))}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Retención de Datos</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Consentimiento de Retención</Label>
                      <p className="text-sm text-muted-foreground">Permitir el almacenamiento de datos históricos</p>
                    </div>
                    <Switch
                      checked={privacySettings.dataRetentionConsent}
                      onCheckedChange={(checked) => setPrivacySettings(prev => ({ ...prev, dataRetentionConsent: checked }))}
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" className="gap-2">
                    <Download className="h-4 w-4" />
                    Descargar Mis Datos
                  </Button>
                  <Button variant="destructive" className="gap-2">
                    <Trash2 className="h-4 w-4" />
                    Eliminar Mi Cuenta
                  </Button>
                </div>
              </div>

              <Button onClick={() => handleSave('privacy')} disabled={saveStatus === 'saving'}>
                <Save className="h-4 w-4 mr-2" />
                {getSaveButtonText()}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Preferences */}
        <TabsContent value="preferences">
          <Card>
            <CardHeader>
              <CardTitle>Preferencias Generales</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Idioma y Región</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="language">Idioma</Label>
                    <Select value={preferencesSettings.language} onValueChange={(value) => setPreferencesSettings(prev => ({ ...prev, language: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="pt">Português</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="currency">Moneda</Label>
                    <Select value={preferencesSettings.currency} onValueChange={(value) => setPreferencesSettings(prev => ({ ...prev, currency: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ARS">Peso Argentino (ARS)</SelectItem>
                        <SelectItem value="USD">Dólar Americano (USD)</SelectItem>
                        <SelectItem value="EUR">Euro (EUR)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Apariencia</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="theme">Tema</Label>
                    <Select value={preferencesSettings.theme} onValueChange={(value) => setPreferencesSettings(prev => ({ ...prev, theme: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="system">Sistema</SelectItem>
                        <SelectItem value="light">Claro</SelectItem>
                        <SelectItem value="dark">Oscuro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dateFormat">Formato de Fecha</Label>
                    <Select value={preferencesSettings.dateFormat} onValueChange={(value) => setPreferencesSettings(prev => ({ ...prev, dateFormat: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Configuración de Puntos</h3>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label>Canje Automático</Label>
                    <p className="text-sm text-muted-foreground">Canjear automáticamente puntos por beneficios disponibles</p>
                  </div>
                  <Switch
                    checked={preferencesSettings.autoRedeem}
                    onCheckedChange={(checked) => setPreferencesSettings(prev => ({ ...prev, autoRedeem: checked }))}
                  />
                </div>
              </div>

              <Button onClick={() => handleSave('preferences')} disabled={saveStatus === 'saving'}>
                <Save className="h-4 w-4 mr-2" />
                {getSaveButtonText()}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
