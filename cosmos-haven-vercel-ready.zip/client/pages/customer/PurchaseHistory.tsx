import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  Filter, 
  Calendar, 
  MapPin,
  Award,
  DollarSign,
  ShoppingBag,
  Download,
  Eye
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Customer } from '@shared/types';
import { mockPurchases } from '@/data/mockData';

export default function PurchaseHistory() {
  const { user } = useAuth();
  const customer = user as Customer;
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [branchFilter, setBranchFilter] = useState('all');

  if (!customer || customer.role !== 'CUSTOMER') {
    return <div>Error: No se pudo cargar la información del cliente</div>;
  }

  // Filter purchases for this customer
  const customerPurchases = mockPurchases.filter(p => p.customerId === customer.id);

  const filteredPurchases = customerPurchases.filter(purchase => {
    const matchesSearch = purchase.products.some(product => 
      product.toLowerCase().includes(searchTerm.toLowerCase())
    ) || purchase.branch?.name.toLowerCase().includes(searchTerm.toLowerCase());

    const purchaseDate = new Date(purchase.date);
    const now = new Date();
    
    let matchesDate = true;
    if (dateFilter === 'week') {
      const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      matchesDate = purchaseDate >= oneWeekAgo;
    } else if (dateFilter === 'month') {
      const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      matchesDate = purchaseDate >= oneMonthAgo;
    } else if (dateFilter === '3months') {
      const threeMonthsAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
      matchesDate = purchaseDate >= threeMonthsAgo;
    }

    const matchesBranch = branchFilter === 'all' || purchase.branchId === branchFilter;

    return matchesSearch && matchesDate && matchesBranch;
  });

  const totalSpent = filteredPurchases.reduce((sum, p) => sum + p.amount, 0);
  const totalPoints = filteredPurchases.reduce((sum, p) => sum + p.pointsEarned, 0);
  const averageTicket = filteredPurchases.length > 0 ? totalSpent / filteredPurchases.length : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Historial de Compras</h1>
          <p className="text-muted-foreground">
            Revisa todas tus compras y puntos ganados
          </p>
        </div>
        
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Descargar PDF
        </Button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Compras</p>
                <p className="text-2xl font-bold">{filteredPurchases.length}</p>
              </div>
              <ShoppingBag className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Gastado</p>
                <p className="text-2xl font-bold">${totalSpent.toLocaleString()}</p>
              </div>
              <DollarSign className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Ganados</p>
                <p className="text-2xl font-bold text-success">{totalPoints}</p>
              </div>
              <Award className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Ticket Promedio</p>
                <p className="text-2xl font-bold">${averageTicket.toLocaleString()}</p>
              </div>
              <MapPin className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por producto o sucursal..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="w-48">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <SelectValue placeholder="Filtrar por fecha" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las fechas</SelectItem>
                  <SelectItem value="week">Última semana</SelectItem>
                  <SelectItem value="month">Último mes</SelectItem>
                  <SelectItem value="3months">Últimos 3 meses</SelectItem>
                </SelectContent>
              </Select>

              <Select value={branchFilter} onValueChange={setBranchFilter}>
                <SelectTrigger className="w-48">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <SelectValue placeholder="Filtrar por sucursal" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las sucursales</SelectItem>
                  <SelectItem value="branch-001">Sucursal Centro</SelectItem>
                  <SelectItem value="branch-002">Sucursal Palermo</SelectItem>
                  <SelectItem value="branch-003">Sucursal Belgrano</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Purchase List */}
      <Card>
        <CardHeader>
          <CardTitle>Compras ({filteredPurchases.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredPurchases.map((purchase) => (
              <div key={purchase.id} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <ShoppingBag className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Compra #{purchase.id.slice(-6)}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>
                            {new Date(purchase.date).toLocaleDateString('es-AR', {
                              weekday: 'long',
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="ml-13 space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-3 w-3 text-muted-foreground" />
                        <span>{purchase.branch?.name}</span>
                      </div>
                      
                      <div className="text-sm">
                        <p className="text-muted-foreground">Productos:</p>
                        <p>{purchase.products.join(', ')}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right ml-4">
                    <div className="space-y-2">
                      <div>
                        <p className="text-2xl font-bold">${purchase.amount.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">Total</p>
                      </div>
                      
                      <Badge variant="outline" className="gap-1">
                        <Award className="h-3 w-3" />
                        +{purchase.pointsEarned} puntos
                      </Badge>
                      
                      <div className="pt-2">
                        <Button variant="ghost" size="sm" className="gap-2">
                          <Eye className="h-3 w-3" />
                          Ver detalles
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredPurchases.length === 0 && (
            <div className="text-center py-8">
              <ShoppingBag className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No se encontraron compras</h3>
              <p className="text-muted-foreground">
                {searchTerm || dateFilter !== 'all' || branchFilter !== 'all' 
                  ? 'Intenta ajustar los filtros de búsqueda'
                  : 'Aún no has realizado ninguna compra'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Monthly Summary */}
      {filteredPurchases.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Resumen por Mes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {['Enero', 'Febrero', 'Marzo'].map((month, index) => {
                const monthPurchases = Math.floor(Math.random() * 5) + 1;
                const monthAmount = Math.floor(Math.random() * 10000) + 5000;
                const monthPoints = Math.floor(monthAmount / 1000) * 10;
                
                return (
                  <div key={month} className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">{month} 2024</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Compras:</span>
                        <span className="font-medium">{monthPurchases}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total:</span>
                        <span className="font-medium">${monthAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Puntos:</span>
                        <span className="font-medium text-primary">{monthPoints}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
