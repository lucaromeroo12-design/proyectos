import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Users, TrendingUp, Plus, CreditCard } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { BranchManager } from '@shared/types';
import { mockBranchMetrics, mockBranches, mockCustomers } from '@/data/mockData';

export default function BranchDashboard() {
  const { user } = useAuth();
  const branchManager = user as BranchManager;

  if (!branchManager || branchManager.role !== 'BRANCH') {
    return <div>Error: No se pudo cargar la información de la sucursal</div>;
  }

  const branch = mockBranches.find(b => b.id === branchManager.branchId);
  const metrics = mockBranchMetrics;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard - {branch?.name}</h1>
          <p className="text-muted-foreground">Panel de gestión de sucursal</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Registrar Venta
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventas del Mes</CardTitle>
            <BarChart3 className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${metrics.totalSales.toLocaleString()}</div>
            <p className="text-xs text-success">
              +12% vs mes anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes Activos</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.customerCount}</div>
            <p className="text-xs text-muted-foreground">
              Este mes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ticket Promedio</CardTitle>
            <CreditCard className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${metrics.averageTicket.toLocaleString()}</div>
            <p className="text-xs text-success">
              +5% vs mes anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventas Semanales</CardTitle>
            <TrendingUp className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-xs text-muted-foreground">
              Esta semana
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts and Rankings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ventas por Semana</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {metrics.salesByWeek.map((week, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm">{week.week}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-24 bg-muted rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${(week.sales / 20000) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium">${week.sales.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Clientes de la Sucursal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {metrics.topCustomers.map((customer, index) => (
                <div key={customer.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-bold">{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-medium">{customer.name}</p>
                      <p className="text-sm text-muted-foreground">{customer.points} puntos</p>
                    </div>
                  </div>
                  <Badge variant="outline">{customer.loyaltyLevel}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Sales */}
      <Card>
        <CardHeader>
          <CardTitle>Ventas Recientes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {metrics.recentSales.map((sale) => (
              <div key={sale.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium">Cliente: {mockCustomers.find(c => c.id === sale.customerId)?.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(sale.date).toLocaleDateString()} - {sale.products.join(', ')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-medium">${sale.amount.toLocaleString()}</p>
                  <p className="text-sm text-primary">+{sale.pointsEarned} puntos</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
