import { useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export function useApi() {
  const { token, logout } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const makeRequest = useCallback(async <T = any>(
    url: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> => {
    setIsLoading(true);
    setError(null);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...options.headers as Record<string, string>,
      };

      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await fetch(url, {
        ...options,
        headers,
      });

      const data = await response.json();

      // Handle authentication errors
      if (response.status === 401) {
        logout();
        return {
          success: false,
          error: 'Session expired. Please login again.',
        };
      }

      if (!response.ok) {
        return {
          success: false,
          error: data.message || `HTTP error! status: ${response.status}`,
        };
      }

      return {
        success: true,
        data: data.success !== undefined ? data : { success: true, ...data },
      };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Network error';
      setError(errorMessage);
      return {
        success: false,
        error: errorMessage,
      };
    } finally {
      setIsLoading(false);
    }
  }, [token, logout]);

  const get = useCallback(<T = any>(url: string) => {
    return makeRequest<T>(url, { method: 'GET' });
  }, [makeRequest]);

  const post = useCallback(<T = any>(url: string, body?: any) => {
    return makeRequest<T>(url, {
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
    });
  }, [makeRequest]);

  const put = useCallback(<T = any>(url: string, body?: any) => {
    return makeRequest<T>(url, {
      method: 'PUT',
      body: body ? JSON.stringify(body) : undefined,
    });
  }, [makeRequest]);

  const del = useCallback(<T = any>(url: string) => {
    return makeRequest<T>(url, { method: 'DELETE' });
  }, [makeRequest]);

  return {
    get,
    post,
    put,
    delete: del,
    makeRequest,
    isLoading,
    error,
  };
}

// Specialized hooks for common API calls
export function useCustomerApi() {
  const api = useApi();

  return {
    getDashboard: () => api.get('/api/customer/dashboard'),
    getPointsHistory: () => api.get('/api/customer/points-history'),
    getBenefits: () => api.get('/api/customer/benefits'),
    ...api,
  };
}

export function useAdminApi() {
  const api = useApi();

  return {
    getDashboard: () => api.get('/api/admin/dashboard'),
    getCustomers: (params?: Record<string, any>) => {
      const queryParams = params ? '?' + new URLSearchParams(params).toString() : '';
      return api.get(`/api/admin/customers${queryParams}`);
    },
    getBranches: () => api.get('/api/admin/branches'),
    ...api,
  };
}
