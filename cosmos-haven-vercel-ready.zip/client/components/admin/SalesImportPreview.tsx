import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  CheckCircle, 
  AlertTriangle, 
  Users, 
  TrendingUp, 
  FileText,
  Award
} from 'lucide-react';
import { SalesPreviewResponse } from '@shared/salesImport';

interface SalesImportPreviewProps {
  previewData: SalesPreviewResponse;
  onConfirm: () => void;
  onCancel: () => void;
  isProcessing?: boolean;
}

export function SalesImportPreview({ 
  previewData, 
  onConfirm, 
  onCancel, 
  isProcessing 
}: SalesImportPreviewProps) {
  const { preview, totalRows, validRows, invalidRows } = previewData;
  const hasErrors = invalidRows > 0;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Filas</p>
                <p className="text-2xl font-bold">{totalRows}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Válidas</p>
                <p className="text-2xl font-bold text-success">{validRows}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Con Errores</p>
                <p className="text-2xl font-bold text-destructive">{invalidRows}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-destructive" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Puntos Totales</p>
                <p className="text-2xl font-bold text-primary">
                  {preview.reduce((sum, row) => sum + row.pointsToEarn, 0).toLocaleString()}
                </p>
              </div>
              <Award className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      {hasErrors && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Se encontraron {invalidRows} filas con errores que serán ignoradas durante la importación.
          </AlertDescription>
        </Alert>
      )}

      {validRows === 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            No se encontraron filas válidas para importar. Verifica el formato del archivo.
          </AlertDescription>
        </Alert>
      )}

      {/* Preview Table */}
      <Card>
        <CardHeader>
          <CardTitle>Vista Previa de Datos (primeras 20 filas)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Fila</th>
                  <th className="text-left p-2">Cliente</th>
                  <th className="text-left p-2">DNI</th>
                  <th className="text-left p-2">Sucursal</th>
                  <th className="text-left p-2">Fecha</th>
                  <th className="text-right p-2">Monto</th>
                  <th className="text-right p-2">Puntos</th>
                  <th className="text-left p-2">Factura</th>
                  <th className="text-center p-2">Estado</th>
                </tr>
              </thead>
              <tbody>
                {preview.map((row) => (
                  <tr 
                    key={row.row} 
                    className={`border-b ${
                      row.isValid ? 'bg-background' : 'bg-destructive/5'
                    }`}
                  >
                    <td className="p-2 font-mono text-xs">{row.row}</td>
                    <td className="p-2 max-w-[150px] truncate" title={row.nombre_cliente}>
                      {row.nombre_cliente}
                    </td>
                    <td className="p-2 font-mono">{row.dni_cliente}</td>
                    <td className="p-2 max-w-[120px] truncate" title={row.sucursal}>
                      {row.sucursal}
                    </td>
                    <td className="p-2 font-mono text-xs">{row.fecha}</td>
                    <td className="p-2 text-right font-mono">
                      ${row.monto?.toLocaleString() || '0'}
                    </td>
                    <td className="p-2 text-right font-bold text-primary">
                      {row.pointsToEarn}
                    </td>
                    <td className="p-2 font-mono text-xs max-w-[100px] truncate" title={row.nro_factura}>
                      {row.nro_factura}
                    </td>
                    <td className="p-2 text-center">
                      {row.isValid ? (
                        <Badge variant="default" className="bg-success text-success-foreground">
                          Válida
                        </Badge>
                      ) : (
                        <Badge variant="destructive" title={row.errors.join(', ')}>
                          Error
                        </Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {preview.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No hay datos para mostrar
            </div>
          )}
        </CardContent>
      </Card>

      {/* Error Details */}
      {hasErrors && (
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">Detalles de Errores</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {preview
                .filter(row => !row.isValid)
                .map((row) => (
                  <div key={row.row} className="text-sm border-l-4 border-destructive pl-3 py-1">
                    <span className="font-medium">Fila {row.row}:</span>{' '}
                    <span className="text-muted-foreground">
                      {row.errors.join(', ')}
                    </span>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end gap-3">
        <Button 
          variant="outline" 
          onClick={onCancel}
          disabled={isProcessing}
        >
          Cancelar
        </Button>
        <Button 
          onClick={onConfirm}
          disabled={validRows === 0 || isProcessing}
          className="gap-2"
        >
          {isProcessing ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              Procesando...
            </>
          ) : (
            <>
              <CheckCircle className="h-4 w-4" />
              Confirmar Importación ({validRows} ventas)
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
