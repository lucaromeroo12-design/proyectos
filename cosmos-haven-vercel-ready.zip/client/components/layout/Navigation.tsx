import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  Home,
  Settings,
  LogOut,
  User,
  Gift,
  History,
  BarChart3,
  Users,
  MapPin,
  Award,
  Menu,
  Upload
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { UserRole } from '@shared/types';

const navigationItems: Record<UserRole, Array<{ href: string; label: string; icon: React.ElementType }>> = {
  CUSTOMER: [
    { href: '/dashboard', label: 'Dashboard', icon: Home },
    { href: '/puntos', label: 'Mis Puntos', icon: Award },
    { href: '/beneficios', label: 'Beneficios', icon: Gift },
    { href: '/historial', label: 'Historial', icon: History },
    { href: '/configuracion', label: 'Configuración', icon: Settings },
  ],
  BRANCH: [
    { href: '/dashboard', label: 'Dashboard', icon: Home },
    { href: '/ventas', label: 'Registrar Venta', icon: BarChart3 },
    { href: '/clientes', label: 'Clientes', icon: Users },
    { href: '/estadisticas', label: 'Estadísticas', icon: BarChart3 },
    { href: '/configuracion', label: 'Configuración', icon: Settings },
  ],
  ADMIN: [
    { href: '/dashboard', label: 'Dashboard', icon: Home },
    { href: '/importar-ventas', label: 'Importar Ventas', icon: Upload },
    { href: '/sucursales', label: 'Sucursales', icon: MapPin },
    { href: '/beneficios-admin', label: 'Gestión Beneficios', icon: Gift },
    { href: '/clientes-admin', label: 'Clientes', icon: Users },
    { href: '/reportes', label: 'Reportes', icon: BarChart3 },
    { href: '/configuracion', label: 'Configuración', icon: Settings },
  ],
};

function NavigationContent() {
  const { user, logout } = useAuth();
  const location = useLocation();

  if (!user) return null;

  const items = navigationItems[user.role] || [];

  return (
    <div className="p-4 flex flex-col h-full">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-primary">FidelityApp</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {user.role === 'CUSTOMER' && 'Panel de Cliente'}
          {user.role === 'BRANCH' && 'Panel de Sucursal'}
          {user.role === 'ADMIN' && 'Panel de Administrador'}
        </p>
      </div>

      <div className="flex-1 space-y-2">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.href;
          
          return (
            <Link key={item.href} to={item.href}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className="w-full justify-start"
              >
                <Icon className="h-4 w-4 mr-2" />
                {item.label}
              </Button>
            </Link>
          );
        })}
      </div>

      <div className="border-t border-border pt-4 mt-4">
        <div className="mb-4 p-3 bg-muted/50 rounded-lg">
          <p className="font-medium text-sm truncate">{user.name}</p>
          <p className="text-xs text-muted-foreground truncate">{user.email}</p>
        </div>
        <Button 
          variant="outline" 
          className="w-full justify-start"
          onClick={logout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Cerrar Sesión
        </Button>
      </div>
    </div>
  );
}

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();

  if (!user) return null;

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden lg:flex bg-card border-r border-border w-64 min-h-screen">
        <NavigationContent />
      </nav>

      {/* Mobile Navigation */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-primary">FidelityApp</h1>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <NavigationContent />
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </>
  );
}
