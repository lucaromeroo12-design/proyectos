export type UserRole = 'CUSTOMER' | 'BRANCH' | 'ADMIN';

export type LoyaltyLevel = 'BRONZE' | 'SILVER' | 'GOLD';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  dni?: string;
  branchId?: string;
}

export interface Customer extends User {
  role: 'CUSTOMER';
  dni: string;
  points: number;
  loyaltyLevel: LoyaltyLevel;
  totalSpent: number;
  registrationDate: string;
}

export interface BranchManager extends User {
  role: 'BRANCH';
  branchId: string;
}

export interface Admin extends User {
  role: 'ADMIN';
}

export interface Branch {
  id: string;
  name: string;
  address: string;
  managerId?: string;
  isActive: boolean;
}

export interface Purchase {
  id: string;
  customerId: string;
  branchId: string;
  amount: number;
  pointsEarned: number;
  products: string[];
  date: string;
  invoiceNumber?: string;
  branch?: Branch;
}

export interface ImportedSale {
  nombre_cliente: string;
  dni_cliente: string;
  sucursal: string;
  fecha: string;
  monto: number;
  nro_factura: string;
}

export interface SalesImportResult {
  success: boolean;
  processedCount: number;
  ignoredCount: number;
  errors: string[];
  summary: string;
}

export interface SalesPreview {
  validRows: ImportedSale[];
  invalidRows: Array<{ row: number; data: any; errors: string[] }>;
  totalRows: number;
}

export interface Benefit {
  id: string;
  title: string;
  description: string;
  pointsCost: number;
  type: 'discount' | 'gift' | 'coupon';
  value: string;
  isActive: boolean;
  validUntil?: string;
  minLoyaltyLevel?: LoyaltyLevel;
}

export interface Redemption {
  id: string;
  customerId: string;
  benefitId: string;
  pointsUsed: number;
  date: string;
  status: 'pending' | 'used' | 'expired';
  benefit?: Benefit;
}

export interface DashboardMetrics {
  totalSales: number;
  totalCustomers: number;
  totalPointsRedeemed: number;
  averageTicket: number;
  topCustomers: Customer[];
  recentTransactions: Purchase[];
  salesByMonth: Array<{ month: string; sales: number }>;
  totalImportedSales?: number;
}

export interface BranchMetrics {
  branchId: string;
  totalSales: number;
  customerCount: number;
  averageTicket: number;
  topCustomers: Customer[];
  recentSales: Purchase[];
  salesByWeek: Array<{ week: string; sales: number }>;
}
