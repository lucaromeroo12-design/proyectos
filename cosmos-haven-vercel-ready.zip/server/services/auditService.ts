import prisma from './database';

export interface AuditLogData {
  userId?: string;
  event: string;
  details: string;
  tableName?: string;
  recordId?: string;
  ipAddress?: string;
  userAgent?: string;
}

/**
 * Log an audit event
 */
export async function logAuditEvent(data: AuditLogData): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        userId: data.userId || null,
        event: data.event,
        details: data.details,
        tableName: data.tableName || null,
        recordId: data.recordId || null,
        ipAddress: data.ipAddress || null,
        userAgent: data.userAgent || null,
      },
    });
  } catch (error) {
    console.error('Failed to log audit event:', error);
    // Don't throw error to prevent disrupting main business logic
  }
}

/**
 * Get audit logs with pagination and filtering
 */
export async function getAuditLogs(params: {
  page?: number;
  limit?: number;
  userId?: string;
  event?: string;
  startDate?: Date;
  endDate?: Date;
}) {
  const { page = 1, limit = 50, userId, event, startDate, endDate } = params;
  const skip = (page - 1) * limit;

  const where: any = {};

  if (userId) where.userId = userId;
  if (event) where.event = { contains: event };
  if (startDate && endDate) {
    where.createdAt = {
      gte: startDate,
      lte: endDate,
    };
  } else if (startDate) {
    where.createdAt = { gte: startDate };
  } else if (endDate) {
    where.createdAt = { lte: endDate };
  }

  const [logs, total] = await Promise.all([
    prisma.auditLog.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            role: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.auditLog.count({ where }),
  ]);

  return {
    logs,
    total,
    page,
    limit,
    pages: Math.ceil(total / limit),
  };
}

/**
 * Common audit event types
 */
export const AUDIT_EVENTS = {
  // User events
  USER_LOGIN: 'USER_LOGIN',
  USER_LOGOUT: 'USER_LOGOUT',
  USER_REGISTER: 'USER_REGISTER',
  
  // Sales events
  SALES_IMPORT: 'SALES_IMPORT',
  PURCHASE_CREATE: 'PURCHASE_CREATE',
  
  // Points events
  POINTS_UPDATE: 'POINTS_UPDATE',
  LOYALTY_LEVEL_CHANGE: 'LOYALTY_LEVEL_CHANGE',
  
  // Benefit events
  BENEFIT_CREATE: 'BENEFIT_CREATE',
  BENEFIT_UPDATE: 'BENEFIT_UPDATE',
  BENEFIT_DELETE: 'BENEFIT_DELETE',
  BENEFIT_REDEEM: 'BENEFIT_REDEEM',
  
  // Branch events
  BRANCH_CREATE: 'BRANCH_CREATE',
  BRANCH_UPDATE: 'BRANCH_UPDATE',
  
  // Admin events
  ADMIN_ACTION: 'ADMIN_ACTION',
} as const;
