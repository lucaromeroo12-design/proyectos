import * as XLSX from 'xlsx';
import csv from 'csv-parser';
import { Readable } from 'stream';
import {
  ImportedSale,
  Customer,
  Purchase,
  Branch,
  SalesImportResult,
  SalesPreviewResponse
} from '../../shared/types';
import {
  calculatePoints,
  validateSaleRow,
  REQUIRED_COLUMNS
} from '../../shared/salesImport';

// Mock databases - in real app, these would be actual database operations
let mockCustomers: Customer[] = [
  {
    id: 'customer-1',
    email: 'cliente@demo.com',
    name: 'María González',
    role: 'customer',
    dni: '12345678',
    points: 1250,
    loyaltyLevel: 'silver',
    totalSpent: 15000,
    registrationDate: '2023-01-15'
  }
];

let mockBranches: Branch[] = [
  { id: 'branch-001', name: 'Sucursal Centro', address: 'Av. Corrientes 1234, CABA', managerId: 'branch-1', isActive: true },
  { id: 'branch-002', name: 'Sucursal Palermo', address: 'Av. Santa Fe 5678, CABA', managerId: 'branch-2', isActive: true },
  { id: 'branch-003', name: 'Sucursal Belgrano', address: 'Av. Cabildo 9876, CABA', managerId: 'branch-3', isActive: true },
];

let mockPurchases: Purchase[] = [];
let processedInvoices = new Set<string>();

export class SalesImportService {
  static async parseFile(buffer: Buffer, fileName: string): Promise<any[]> {
    const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls');
    
    if (isExcel) {
      return this.parseExcelFile(buffer);
    } else {
      return this.parseCSVFile(buffer);
    }
  }

  private static parseExcelFile(buffer: Buffer): any[] {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    
    return XLSX.utils.sheet_to_json(worksheet, { 
      defval: '',
      blankrows: false 
    });
  }

  private static async parseCSVFile(buffer: Buffer): Promise<any[]> {
    return new Promise((resolve, reject) => {
      const results: any[] = [];
      const stream = Readable.from(buffer.toString());
      
      stream
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', () => resolve(results))
        .on('error', reject);
    });
  }

  static async previewSales(buffer: Buffer, fileName: string): Promise<SalesPreviewResponse> {
    try {
      const rawData = await this.parseFile(buffer, fileName);
      const preview = [];
      let validRows = 0;
      let invalidRows = 0;

      for (let i = 0; i < Math.min(rawData.length, 20); i++) {
        const row = rawData[i];
        const validation = validateSaleRow(row);
        const pointsToEarn = row.monto ? calculatePoints(Number(row.monto)) : 0;

        preview.push({
          row: i + 1,
          nombre_cliente: row.nombre_cliente || '',
          dni_cliente: row.dni_cliente?.toString() || '',
          sucursal: row.sucursal || '',
          fecha: row.fecha || '',
          monto: Number(row.monto) || 0,
          nro_factura: row.nro_factura?.toString() || '',
          pointsToEarn,
          isValid: validation.isValid,
          errors: validation.errors
        });

        if (validation.isValid) {
          validRows++;
        } else {
          invalidRows++;
        }
      }

      return {
        success: true,
        preview,
        totalRows: rawData.length,
        validRows,
        invalidRows
      };
    } catch (error) {
      return {
        success: false,
        preview: [],
        totalRows: 0,
        validRows: 0,
        invalidRows: 0
      };
    }
  }

  static async processSales(buffer: Buffer, fileName: string): Promise<SalesImportResult> {
    try {
      const rawData = await this.parseFile(buffer, fileName);
      let processedCount = 0;
      let ignoredCount = 0;
      const errors: string[] = [];
      let newCustomersCreated = 0;
      let totalPointsAdded = 0;

      for (let i = 0; i < rawData.length; i++) {
        const row = rawData[i];
        const validation = validateSaleRow(row);

        if (!validation.isValid) {
          errors.push(`Fila ${i + 1}: ${validation.errors.join(', ')}`);
          ignoredCount++;
          continue;
        }

        // Check for duplicate invoice
        if (processedInvoices.has(row.nro_factura)) {
          ignoredCount++;
          continue;
        }

        try {
          // Find or create customer
          let customer = mockCustomers.find(c => c.dni === row.dni_cliente.toString());
          if (!customer) {
            customer = this.createCustomer(row.dni_cliente.toString(), row.nombre_cliente);
            mockCustomers.push(customer);
            newCustomersCreated++;
          }

          // Find or create branch
          let branch = mockBranches.find(b => 
            b.name.toLowerCase() === row.sucursal.toLowerCase()
          );
          if (!branch) {
            branch = this.createBranch(row.sucursal);
            mockBranches.push(branch);
          }

          // Calculate points and create purchase
          const pointsEarned = calculatePoints(Number(row.monto));
          const purchase = this.createPurchase(
            customer.id,
            branch.id,
            Number(row.monto),
            pointsEarned,
            row.fecha,
            row.nro_factura.toString()
          );

          // Update customer points and total spent
          customer.points += pointsEarned;
          customer.totalSpent += Number(row.monto);
          this.updateLoyaltyLevel(customer);

          mockPurchases.push(purchase);
          processedInvoices.add(row.nro_factura.toString());
          totalPointsAdded += pointsEarned;
          processedCount++;

        } catch (error) {
          errors.push(`Fila ${i + 1}: Error al procesar - ${error}`);
          ignoredCount++;
        }
      }

      const summary = `Se cargaron correctamente ${processedCount} ventas. Se ignoraron ${ignoredCount} registros.`;
      if (newCustomersCreated > 0) {
        summary + ` Se crearon ${newCustomersCreated} nuevos clientes.`;
      }

      return {
        success: true,
        processedCount,
        ignoredCount,
        errors,
        summary
      };

    } catch (error) {
      return {
        success: false,
        processedCount: 0,
        ignoredCount: 0,
        errors: [`Error al procesar archivo: ${error}`],
        summary: 'Error al procesar el archivo'
      };
    }
  }

  private static createCustomer(dni: string, name: string): Customer {
    return {
      id: `customer-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      email: `${dni}@generado.com`,
      name: name,
      role: 'customer',
      dni: dni,
      points: 0,
      loyaltyLevel: 'bronze',
      totalSpent: 0,
      registrationDate: new Date().toISOString()
    };
  }

  private static createBranch(name: string): Branch {
    return {
      id: `branch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: name,
      address: 'Dirección a definir',
      isActive: true
    };
  }

  private static createPurchase(
    customerId: string,
    branchId: string,
    amount: number,
    pointsEarned: number,
    date: string,
    invoiceNumber: string
  ): Purchase {
    return {
      id: `purchase-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      customerId,
      branchId,
      amount,
      pointsEarned,
      products: ['Venta importada'],
      date: new Date(date).toISOString(),
      invoiceNumber
    };
  }

  private static updateLoyaltyLevel(customer: Customer): void {
    if (customer.totalSpent >= 30000) {
      customer.loyaltyLevel = 'gold';
    } else if (customer.totalSpent >= 10000) {
      customer.loyaltyLevel = 'silver';
    } else {
      customer.loyaltyLevel = 'bronze';
    }
  }

  // Getter methods for accessing the mock data (for demo purposes)
  static getCustomers(): Customer[] {
    return mockCustomers;
  }

  static getPurchases(): Purchase[] {
    return mockPurchases;
  }

  static getBranches(): Branch[] {
    return mockBranches;
  }
}
