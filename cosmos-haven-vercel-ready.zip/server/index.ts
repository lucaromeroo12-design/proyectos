import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  uploadMiddleware,
  previewSalesImport,
  processSalesImport
} from "./routes/salesImport";
import { login, register, getProfile, logout } from "./routes/auth";
import {
  getCustomerDashboard,
  getCustomerPointsHistory,
  getAvailableBenefits
} from "./routes/customer";
import {
  getAdminDashboard,
  getCustomersData,
  getBranchesData
} from "./routes/admin";
import { requireAuth, requireAdmin, requireCustomer } from "./middleware/auth";
import { globalErrorHandler, handleUnhandledRejection, handleUncaughtException } from "./middleware/errorHandler";

// Handle uncaught exceptions and unhandled rejections
handleUncaughtException();
handleUnhandledRejection();

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Authentication routes
  app.post("/api/auth/login", login);
  app.post("/api/auth/register", register);
  app.get("/api/auth/profile", requireAuth, getProfile);
  app.post("/api/auth/logout", requireAuth, logout);

  // Customer API routes
  app.get("/api/customer/dashboard", requireAuth, requireCustomer, getCustomerDashboard);
  app.get("/api/customer/points-history", requireAuth, requireCustomer, getCustomerPointsHistory);
  app.get("/api/customer/benefits", requireAuth, requireCustomer, getAvailableBenefits);

  // Admin API routes
  app.get("/api/admin/dashboard", requireAuth, requireAdmin, getAdminDashboard);
  app.get("/api/admin/customers", requireAuth, requireAdmin, getCustomersData);
  app.get("/api/admin/branches", requireAuth, requireAdmin, getBranchesData);

  // Sales import routes (admin only)
  app.post("/api/admin/sales-import/preview", requireAuth, requireAdmin, uploadMiddleware, previewSalesImport);
  app.post("/api/admin/sales-import/process", requireAuth, requireAdmin, uploadMiddleware, processSalesImport);

  // Global error handler (must be last)
  app.use(globalErrorHandler);

  return app;
}
