import { describe, it, expect, beforeAll } from 'vitest';
import { 
  hashPassword, 
  comparePassword, 
  generateToken, 
  verifyToken, 
  extractTokenFromHeader,
  hasRole
} from './auth';
import { UserRole } from '@prisma/client';

// Set test environment variable
process.env.JWT_SECRET = 'test-secret-key';

describe('Auth Utility Functions', () => {
  describe('Password Hashing', () => {
    it('should hash a password', async () => {
      const password = 'testpassword123';
      const hash = await hashPassword(password);
      
      expect(hash).toBeTruthy();
      expect(hash).not.toBe(password);
      expect(hash.length).toBeGreaterThan(50);
    });

    it('should generate different hashes for same password', async () => {
      const password = 'testpassword123';
      const hash1 = await hashPassword(password);
      const hash2 = await hashPassword(password);
      
      expect(hash1).not.toBe(hash2);
    });

    it('should verify correct password', async () => {
      const password = 'testpassword123';
      const hash = await hashPassword(password);
      
      const isValid = await comparePassword(password, hash);
      expect(isValid).toBe(true);
    });

    it('should reject incorrect password', async () => {
      const password = 'testpassword123';
      const wrongPassword = 'wrongpassword';
      const hash = await hashPassword(password);
      
      const isValid = await comparePassword(wrongPassword, hash);
      expect(isValid).toBe(false);
    });
  });

  describe('JWT Token Management', () => {
    it('should generate a valid JWT token', () => {
      const payload = {
        userId: 'user123',
        email: 'test@example.com',
        role: UserRole.CUSTOMER,
      };
      
      const token = generateToken(payload);
      expect(token).toBeTruthy();
      expect(typeof token).toBe('string');
      expect(token.split('.')).toHaveLength(3); // JWT has 3 parts
    });

    it('should verify and decode a valid token', () => {
      const payload = {
        userId: 'user123',
        email: 'test@example.com',
        role: UserRole.CUSTOMER,
      };
      
      const token = generateToken(payload);
      const decoded = verifyToken(token);
      
      expect(decoded.userId).toBe(payload.userId);
      expect(decoded.email).toBe(payload.email);
      expect(decoded.role).toBe(payload.role);
      expect(decoded.iat).toBeTruthy();
      expect(decoded.exp).toBeTruthy();
    });

    it('should throw error for invalid token', () => {
      const invalidToken = 'invalid.token.here';
      
      expect(() => verifyToken(invalidToken)).toThrow('Invalid or expired token');
    });

    it('should throw error for malformed token', () => {
      const malformedToken = 'notajwttoken';
      
      expect(() => verifyToken(malformedToken)).toThrow('Invalid or expired token');
    });
  });

  describe('Token Header Extraction', () => {
    it('should extract token from valid Bearer header', () => {
      const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token';
      const authHeader = `Bearer ${token}`;
      
      const extracted = extractTokenFromHeader(authHeader);
      expect(extracted).toBe(token);
    });

    it('should return null for invalid header format', () => {
      const invalidHeaders = [
        'Token eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token',
        'Bearer',
        '',
      ];
      
      invalidHeaders.forEach(header => {
        const extracted = extractTokenFromHeader(header);
        expect(extracted).toBeNull();
      });
    });

    it('should return null for undefined header', () => {
      const extracted = extractTokenFromHeader(undefined);
      expect(extracted).toBeNull();
    });
  });

  describe('Role Management', () => {
    it('should correctly identify if user has required role', () => {
      // User has exact role
      expect(hasRole(UserRole.ADMIN, [UserRole.ADMIN])).toBe(true);
      expect(hasRole(UserRole.CUSTOMER, [UserRole.CUSTOMER])).toBe(true);
      
      // User has one of multiple required roles
      expect(hasRole(UserRole.ADMIN, [UserRole.ADMIN, UserRole.BRANCH])).toBe(true);
      expect(hasRole(UserRole.BRANCH, [UserRole.ADMIN, UserRole.BRANCH])).toBe(true);
      
      // User doesn't have required role
      expect(hasRole(UserRole.CUSTOMER, [UserRole.ADMIN])).toBe(false);
      expect(hasRole(UserRole.CUSTOMER, [UserRole.ADMIN, UserRole.BRANCH])).toBe(false);
    });

    it('should handle empty required roles array', () => {
      expect(hasRole(UserRole.ADMIN, [])).toBe(false);
      expect(hasRole(UserRole.CUSTOMER, [])).toBe(false);
    });
  });

  describe('Error Handling', () => {
    it('should throw error when JWT_SECRET is not set', () => {
      const originalSecret = process.env.JWT_SECRET;
      delete process.env.JWT_SECRET;
      
      const payload = {
        userId: 'user123',
        email: 'test@example.com',
        role: UserRole.CUSTOMER,
      };
      
      expect(() => generateToken(payload)).toThrow('JWT_SECRET environment variable is not set');
      
      // Restore original secret
      process.env.JWT_SECRET = originalSecret;
    });

    it('should throw error when verifying token without JWT_SECRET', () => {
      const originalSecret = process.env.JWT_SECRET;
      const token = generateToken({
        userId: 'user123',
        email: 'test@example.com',
        role: UserRole.CUSTOMER,
      });
      
      delete process.env.JWT_SECRET;
      
      expect(() => verifyToken(token)).toThrow('JWT_SECRET environment variable is not set');
      
      // Restore original secret
      process.env.JWT_SECRET = originalSecret;
    });
  });
});
