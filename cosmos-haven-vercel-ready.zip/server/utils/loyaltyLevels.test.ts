import { describe, it, expect } from 'vitest';
import { 
  determineLoyaltyLevel, 
  calculatePoints, 
  getNextLevelInfo, 
  LOYALTY_THRESHOLDS 
} from './loyaltyLevels';
import { LoyaltyLevel } from '@prisma/client';

describe('Loyalty Levels Utility Functions', () => {
  describe('calculatePoints', () => {
    it('should calculate points correctly for exact thousands', () => {
      expect(calculatePoints(1000)).toBe(1);
      expect(calculatePoints(5000)).toBe(5);
      expect(calculatePoints(10000)).toBe(10);
    });

    it('should round down for partial amounts', () => {
      expect(calculatePoints(1500)).toBe(1);
      expect(calculatePoints(2999)).toBe(2);
      expect(calculatePoints(999)).toBe(0);
    });

    it('should handle zero and negative amounts', () => {
      expect(calculatePoints(0)).toBe(0);
      expect(calculatePoints(-100)).toBe(0);
    });

    it('should handle large amounts', () => {
      expect(calculatePoints(100000)).toBe(100);
      expect(calculatePoints(999999)).toBe(999);
    });
  });

  describe('determineLoyaltyLevel', () => {
    it('should return BRONZE for amounts below silver threshold', () => {
      expect(determineLoyaltyLevel(0)).toBe(LoyaltyLevel.BRONZE);
      expect(determineLoyaltyLevel(5000)).toBe(LoyaltyLevel.BRONZE);
      expect(determineLoyaltyLevel(9999)).toBe(LoyaltyLevel.BRONZE);
    });

    it('should return SILVER for amounts at or above silver threshold', () => {
      expect(determineLoyaltyLevel(10000)).toBe(LoyaltyLevel.SILVER);
      expect(determineLoyaltyLevel(15000)).toBe(LoyaltyLevel.SILVER);
      expect(determineLoyaltyLevel(29999)).toBe(LoyaltyLevel.SILVER);
    });

    it('should return GOLD for amounts at or above gold threshold', () => {
      expect(determineLoyaltyLevel(30000)).toBe(LoyaltyLevel.GOLD);
      expect(determineLoyaltyLevel(50000)).toBe(LoyaltyLevel.GOLD);
      expect(determineLoyaltyLevel(100000)).toBe(LoyaltyLevel.GOLD);
    });

    it('should handle edge cases at thresholds', () => {
      expect(determineLoyaltyLevel(LOYALTY_THRESHOLDS.SILVER - 1)).toBe(LoyaltyLevel.BRONZE);
      expect(determineLoyaltyLevel(LOYALTY_THRESHOLDS.SILVER)).toBe(LoyaltyLevel.SILVER);
      expect(determineLoyaltyLevel(LOYALTY_THRESHOLDS.GOLD - 1)).toBe(LoyaltyLevel.SILVER);
      expect(determineLoyaltyLevel(LOYALTY_THRESHOLDS.GOLD)).toBe(LoyaltyLevel.GOLD);
    });
  });

  describe('getNextLevelInfo', () => {
    it('should return correct info for BRONZE level', () => {
      const result = getNextLevelInfo(LoyaltyLevel.BRONZE, 5000);
      expect(result).toEqual({
        nextLevel: LoyaltyLevel.SILVER,
        amountNeeded: 5000, // 10000 - 5000
        threshold: 10000,
      });
    });

    it('should return correct info for SILVER level', () => {
      const result = getNextLevelInfo(LoyaltyLevel.SILVER, 15000);
      expect(result).toEqual({
        nextLevel: LoyaltyLevel.GOLD,
        amountNeeded: 15000, // 30000 - 15000
        threshold: 30000,
      });
    });

    it('should return null for GOLD level (max level)', () => {
      const result = getNextLevelInfo(LoyaltyLevel.GOLD, 50000);
      expect(result).toBeNull();
    });

    it('should handle edge cases at thresholds', () => {
      // Customer at exact threshold for next level
      const resultAtSilverThreshold = getNextLevelInfo(LoyaltyLevel.BRONZE, 10000);
      expect(resultAtSilverThreshold?.amountNeeded).toBe(0);

      const resultAtGoldThreshold = getNextLevelInfo(LoyaltyLevel.SILVER, 30000);
      expect(resultAtGoldThreshold?.amountNeeded).toBe(0);
    });
  });

  describe('LOYALTY_THRESHOLDS', () => {
    it('should have correct threshold values', () => {
      expect(LOYALTY_THRESHOLDS.BRONZE).toBe(0);
      expect(LOYALTY_THRESHOLDS.SILVER).toBe(10000);
      expect(LOYALTY_THRESHOLDS.GOLD).toBe(30000);
    });

    it('should have thresholds in ascending order', () => {
      expect(LOYALTY_THRESHOLDS.BRONZE).toBeLessThan(LOYALTY_THRESHOLDS.SILVER);
      expect(LOYALTY_THRESHOLDS.SILVER).toBeLessThan(LOYALTY_THRESHOLDS.GOLD);
    });
  });
});
